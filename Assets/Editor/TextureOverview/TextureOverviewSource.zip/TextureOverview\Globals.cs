﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using UnityEditor;

namespace TextureOverview
{
    public static class Globals
    {
        #region ProductVersionNumber
        /// <summary>
        /// The product version number, eg "24".
        /// </summary>
        public static int ProductVersionNumber
        {
            get
            {
                return 35;
            }
        }
        #endregion

        #region ProductTitle
        /// <summary>
        /// The title of the product, eg "Texture Overview 2.4"
        /// </summary>
        public static string ProductTitle
        {
            get;
            private set;
        }
        #endregion

        #region ProductName
        /// <summary>
        /// The name of the product, without version information.
        /// </summary>
        public static string ProductName
        {
            get
            {
                return "Texture Overview";
            }
        }
        #endregion

        #region ProductId
        /// <summary>
        /// A code-friendly name of the product. Used as key to store settings to EditorPrefs for example.
        /// </summary>
        public static string ProductId
        {
            get
            {
                return "TextureOverview";
            }
        }
        #endregion

        #region ProductAssetStoreUrl
        /// <summary>
        /// The link to the product in the Unity asset store.
        /// </summary>
        public static string ProductAssetStoreUrl
        {
            get
            {
                return "https://www.assetstore.unity3d.com/#/content/10832";
            }
        }
        #endregion

        #region ProductFeedbackUrl
        /// <summary>
        /// The URL to the texture overview forum thread.
        /// </summary>
        public static string ProductFeedbackUrl
        {
            get
            {
                return "http://forum.unity3d.com/threads/197707-Released-Texture-Overview-Plugin";
            }
        }
        #endregion

        #region GpuExpandRgb24ToRgba32
        static int _gpuExpandRgb24ToRgba32 = -1; // -1=uninitialized, 0=false, 1=true

        /// <summary>
        /// Gets whether GPU memory calculations for RGB24 should be handled as those texture were RGBA32.
        /// </summary>
        /// <remarks>
        /// This is actually how any/most GPUs work.
        /// 
        /// See R8G8B8 column here (not supported at all):
        /// http://zp.amsnet.pl/cdragan/query.php?dxversion=9&feature=formats&featuregroup=all&adaptergroup=all&resource=TEXTURE&usage=PLAIN&orientation=horizontal
        /// 
        /// Also see RGB24 vs RGB32 memory usage thread:
        /// https://groups.google.com/forum/#!topic/unity-beta-testing/IFth1v8_vIE
        /// </remarks>
        public static bool GpuExpandRgb24ToRgba32
        {
            get
            {
                if (_gpuExpandRgb24ToRgba32 == -1)
                    _gpuExpandRgb24ToRgba32 = EditorPrefs.GetBool(string.Format("{0}.GpuExpandRgb24ToRgba32", Globals.ProductId), true) ? 1 : 0;
                return _gpuExpandRgb24ToRgba32 > 0;
            }
            set
            {
                var ivalue = value ? 1 : 0;
                if (ivalue != _gpuExpandRgb24ToRgba32)
                {
                    _gpuExpandRgb24ToRgba32 = ivalue;
                    EditorPrefs.SetBool(string.Format("{0}.GpuExpandRgb24ToRgba32", Globals.ProductId), value);
                }
            }
        }
        #endregion

        #region cctor
        static Globals()
        {
            ProductTitle = string.Format("{0} {1:F1}", ProductName, ProductVersionNumber/10.0f);
        }
        #endregion
    }
}
