﻿using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class InstallerWindow : EditorWindow
    {
        #region Private Fields
        int _LayoutCalls;
        string _Title = "";
        string _Message = "";
        string _ErrorMessage = "";
        float _ErrorTime;
        GUIStyle _MessageStyle;
        #endregion

        /// <summary>
        /// Title of the plugin.
        /// </summary>
        public string ProductTitle = "";

        /// <summary>
        /// URL where to give feedback or get help about the plugin.
        /// </summary>
        public string FeedbackUrl = "";

        /// <summary>
        /// URL of the plugin in the asset store.
        /// </summary>
        public string AssetStoreUrl = "";

        void OnGUI()
        {
            // in case of an error, display the error message
            // however, wait 5 seconds before doing so, because sometimes a IOException: Win32 IO returned 1224 occurs
            // but it's harmless. And within these 5 seconds, the windows should be reloaded.
            if (!string.IsNullOrEmpty(_ErrorMessage) && _ErrorTime+5<Time.realtimeSinceStartup)
            {
                DrawInstallFailed();
                return;
            }

            // wait for the first layout call to initialize
            if (_LayoutCalls == 0)
                Init();

            // wait for another layout call to actually replace the executing assembly.
            // we don't immediately replace the assembly, because we want to give unity
            // a change to render our window first, which is blocked during installation.
            if (_LayoutCalls == 2)
            {
                Install();
                AssetDatabase.Refresh();
            }

            if (Event.current.type == EventType.layout)
                _LayoutCalls++;

            // draw the installation message
            GUILayout.Label(_Message, _MessageStyle, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));

            base.Repaint();
        }

        void DrawInstallFailed()
        {
            GUILayout.Label(new GUIContent(_Title + " - Setup failed", EditorFramework.Images.Error16x16), EditorStyles.boldLabel);
            if (GUILayout.Button(new GUIContent(" > Get help in Unity forum", FeedbackUrl), EditorFramework.GUIStyles.Hyperlink))
                Application.OpenURL(FeedbackUrl);
            EditorGUIUtility.AddCursorRect(GUILayoutUtility.GetLastRect(), MouseCursor.Link);

            GUILayout.Space(20);
            GUILayout.Label(_ErrorMessage, EditorStyles.wordWrappedLabel);
            GUILayout.Space(20);
        }

        void Init()
        {
            _Title = string.Format("{0} for Unity {1}", ProductTitle, EditorApplication2.MajorVersion);
            _Message = string.Format("Please wait while {0} is installed.", _Title);
            _MessageStyle = new GUIStyle(EditorStyles.boldLabel);
            _MessageStyle.wordWrap = true;
            _MessageStyle.alignment = TextAnchor.MiddleCenter;

            if (EditorApplication2.MajorVersion < 4)
                _ErrorMessage = string.Format("{0} requires Unity 4.x or Unity 5, but you are using Unity {1}.\n", ProductTitle, Application.unityVersion);
        }

        /// <summary>
        /// Replaces the currently executing assembly with another one.
        /// The file names must the following rules:
        /// * Installed assembly is called ProductName.dll (where ProductName is a placeholder for eg TextureOverview)
        /// * Available assemblies are called ProductName.dll.UnityMajorVersion, eg TextureOverview.dll.Unity4
        /// </summary>
        void Install()
        {
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews(); // register a repaint command, which seems to get executed after import and thus makes sure our window gets redrawn to show the new content
            var version = EditorApplication2.MajorVersion;
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            CopyFile(string.Format("{0}.Unity{1}", asm.Location, version), asm.Location, ref _ErrorMessage);
            CopyFile(string.Format("{0}.mdb.Unity{1}", asm.Location, version), asm.Location + ".mdb", ref _ErrorMessage);
        }

        void CopyFile(string sourcePath, string targetPath, ref string errorMsg)
        {
            try
            {
                System.IO.File.Copy(sourcePath, targetPath, true);
            }
            catch (System.Exception e)
            {
                //Debug.LogException(e);
                _ErrorTime = Time.realtimeSinceStartup;
                errorMsg += string.Format("\nError while copying '{0}' to '{1}'. Please check if the file is read-only.\n", sourcePath, targetPath);
            }
        }
    }
}
