﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class EditorApplication2
    {
        #region Public Fields
        public delegate void PluginDestroyDelegate();
        public static event PluginDestroyDelegate PluginDestroy;
        #endregion

        #region ProjectName
        /// <summary>
        /// Gets the name of the active project.
        /// </summary>
        public static string ProjectName
        {
            get
            {
                var name = ProjectPath;
                name = FileUtil2.GetFileNameWithoutExtension(name);
                return name;
            }
        }
        #endregion

        #region ProjectPath
        /// <summary>
        /// Gets the path of the active project folder, without trailing directory separator.
        /// </summary>
        /// <example>
        /// Windows = "C:/Users/myself/Projects/MyUnityGame"
        /// Mac OS  = "/Users/myself/Projects/MyUnityGame"
        /// </example>
        public static string ProjectPath
        {
            get
            {
                var path = UnityEngine.Application.dataPath;
                if (path.EndsWith("/Assets/", StringComparison.OrdinalIgnoreCase))
                    path = path.Substring(0, path.Length - "/Assets/".Length);
                else if (path.EndsWith("/Assets", StringComparison.OrdinalIgnoreCase))
                    path = path.Substring(0, path.Length - "/Assets".Length);

                return path;
            }
        }
        #endregion

        #region LibraryPath
        /// <summary>
        /// Gets the library path of the active project folder, without trailing directory separator.
        /// </summary>
        /// <example>
        /// "[path to project folder]/Library"
        /// </example>
        public static string LibraryPath
        {
            get
            {
                return ProjectPath + "/Library";
            }
        }
        #endregion

        #region Version
        /// <summary>
        /// Gets the major editor version.
        /// </summary>
        public static int MajorVersion
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the minor editor version.
        /// </summary>
        public static int MinorVersion
        {
            get;
            private set;
        }
        #endregion

        #region ctor
        static EditorApplication2()
        {
            var versionNumbers = Application.unityVersion.Split('.');
            MajorVersion = int.Parse(versionNumbers[0]);
            MinorVersion = int.Parse(versionNumbers[1]);
        }
        #endregion

        #region IsVersionOrHigher
        /// <summary>
        /// Gets whether the editor version is equal or higher than the specified version.
        /// </summary>
        public static bool IsVersionOrHigher(int major, int minor)
        {
            if (MajorVersion > major)
                return true;

            if (MajorVersion == major && MinorVersion >= minor)
                return true;

            return false;
        }
        #endregion

        #region OnPluginDestroy
        /// <summary>
        /// Must be called by the editor extension on EditorWindow.OnDestroy()
        /// to notify all subcribed sub-systems to release their allocated resources.
        /// </summary>
        public static void OnPluginDestroy()
        {
            if (null != PluginDestroy)
            {
                var cb = PluginDestroy;
                cb.Invoke();
            }
        }
        #endregion

        #region FrameObject
        /// <summary>
        /// Focuses the specified obj in the SceneView.
        /// </summary>
        /// <remarks>This is the function you find in the main menu 'Edit/Frame Selected'</remarks>
        /// <param name="obj">The object to focus.</param>
        public static void FrameObject(UnityEngine.Object obj)
        {
            if (obj == null)
                return;

            var oldactiveObject = Selection.activeObject;
            var oldobjects = Selection.objects;
            try
            {
                Selection.activeObject = obj;
                Selection.objects = new[] { obj };

                if (null != SceneView.lastActiveSceneView)
                    SceneView.lastActiveSceneView.FrameSelected();
            }
            finally
            {
                Selection.activeObject = oldactiveObject;
                Selection.objects = oldobjects;
            }
        }
        #endregion

        #region FindReferencesInScene
        /// <summary>
        /// Highlights the specified objects in the SceneView.
        /// </summary>
        /// <remarks>This is the function you find in the main menu 'Assets/Find References in Scene'</remarks>
        /// <param name="objects">The objects.</param>
        public static void FindReferencesInScene(UnityEngine.Object obj)
        {
            if (null == obj)
            {
                Debug.LogError(string.Format("FindReferencesInScene: The specified obj is null."));
                return;
            }

            var assetpath = AssetDatabase.GetAssetPath(obj);
            var searchtext = "";

            // if the obj has no asset path it might be a builtin asset or something created via scripting
            if (string.IsNullOrEmpty(assetpath))
            {
                searchtext = string.Format("ref:{0}:\"\"", obj.GetInstanceID());
            }
            else
            {
                // get rid of the 'Assets/' infront of the path
                if (assetpath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                    assetpath = assetpath.Substring("Assets/".Length);

                // if it's a main asset, just set the path,
                // otherwise set the instanceID
                if (AssetDatabase.IsMainAsset(obj))
                    searchtext = string.Format("ref:\"{0}\"", assetpath);
                else
                    searchtext = string.Format("ref:{0}:\"{1}\"", obj.GetInstanceID(), assetpath);
            }

            SearchableEditorWindow2.SetHierarchySearchFilter(searchtext, SearchableEditorWindow.SearchMode.All);
        }
        #endregion

        #region OpenPdfManual
        /// <summary>
        /// Opens the .pdf file that uses the same name as the plugin dll.
        /// The .pdf file must be deployed next to the plugin dll.
        /// </summary>
        public static void OpenPdfManual()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            var assemblypath = assembly.Location;
            var directory = System.IO.Path.GetDirectoryName(assembly.Location);
            var filename = System.IO.Path.GetFileNameWithoutExtension(assembly.Location);
            var pdfpath = System.IO.Path.Combine(directory, filename + ".pdf");
            if (!System.IO.File.Exists(pdfpath))
            {
                EditorUtility.DisplayDialog("", string.Format("Could not find file '{0}'", pdfpath), "OK");
                return;
            }

            EditorUtility.OpenWithDefaultApp(pdfpath);
        }
        #endregion

        #region OpenAssets
        /// <summary>
        /// Opens the specified objects with their default application.
        /// </summary>
        /// <param name="objects">The objects to open</param>
        public static void OpenAssets(UnityEngine.Object[] objects)
        {
            OpenAssets(objects, 3);
        }

        /// <summary>
        /// Opens the specified objects with their default application.
        /// </summary>
        /// <param name="objects">The objects to open</param>
        /// <param name="dialogthreshold">The count of objects that is necessary to display a confirmation dialog.</param>
        public static void OpenAssets(UnityEngine.Object[] objects, int dialogthreshold)
        {
            var paths = new List<string>();
            foreach (var obj in objects)
            {
                var path = AssetDatabase.GetAssetPath(obj);
                if (!string.IsNullOrEmpty(path))
                    paths.Add(path);
            }

            OpenAssets(paths.ToArray(), dialogthreshold);
        }
        #endregion

        #region OpenAssets
        /// <summary>
        /// Opens the specified objects with their default application.
        /// </summary>
        /// <param name="paths">The paths to open</param>
        public static void OpenAssets(string[] paths)
        {
            OpenAssets(paths, 3);
        }

        /// <summary>
        /// Opens the specified objects with their default application.
        /// </summary>
        /// <param name="paths">The paths to open</param>
        /// <param name="dialogthreshold">The count of objects that is necessary to display a confirmation dialog.</param>
        public static void OpenAssets(string[] paths, int dialogthreshold)
        {
            if (null == paths || paths.Length == 0)
                return;

            // check if suspiciously many objects are selected
            // and display a message before actually opening so many windows.
            if (dialogthreshold > 0 && paths.Length > dialogthreshold)
            {
                if (!EditorUtility.DisplayDialog("Open Assets", string.Format("You are about to open {0} assets, do you want to continue?", paths.Length), "Open", "Cancel"))
                    return;
            }

            foreach (var path in paths)
            {
                EditorUtility.OpenWithDefaultApp(path);
            }
        }
        #endregion

        #region ShowInExplorer
        /// <summary>
        /// Shows the specified objects in the default file browser.
        /// </summary>
        /// <param name="objects">The objects to show in the file browser</param>
        public static void ShowInExplorer(UnityEngine.Object[] objects)
        {
            ShowInExplorer(objects, 3);
        }

        /// <summary>
        /// Shows the specified objects in the default file browser.
        /// </summary>
        /// <param name="objects">The objects to show in the file browser</param>
        /// <param name="dialogthreshold">The count of objects that is necessary to display a confirmation dialog.</param>
        public static void ShowInExplorer(UnityEngine.Object[] objects, int dialogthreshold)
        {
            if (null == objects || objects.Length == 0)
                return;

            // do not change the title, because it's how the item is named
            // in the unity assets menu.
            var title = Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer";

            // check if suspiciously many objects are selected
            // and display a message before actually opening so many windows.
            if (dialogthreshold > 0 && objects.Length > dialogthreshold)
            {
                if (!EditorUtility.DisplayDialog(title, string.Format("You are about to open {0} windows, do you want to continue?", objects.Length), "Continue", "Cancel"))
                    return;
            }

            var oldactiveObject = Selection.activeObject;
            var oldobjects = Selection.objects;
            try
            {
                Selection.activeObject = objects[0];
                Selection.objects = objects.ToArray();

                EditorApplication.ExecuteMenuItem("Assets/" + title);
            }
            finally
            {
                Selection.activeObject = oldactiveObject;
                Selection.objects = oldobjects;
            }
        }
        #endregion
    }
}
