//---------------------------------------
// Copyright (c) 2013-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System.Collections.Generic;

namespace EditorFramework
{
    public class AssetBundleManifest2
    {
        public string Name;
        public string Path;
        public List<string> Assets = new List<string>();
        public List<string> Dependencies = new List<string>();
    }

    /// <summary>
    /// Loads an asset bundle manifest file.
    /// </summary>
    /// <remarks>
    /// This class only exists because I wasn't able to get the official manifest API to work.
    /// See Unity bug:
    /// Case 714354 AssetDatabase.LoadAssetAtPath<AssetBundleManifest>() returns null
    /// </remarks>
    public static class AssetBundleManifestParser
    {
        enum Category
        {
            None,
            Assets,
            ClassTypes,
            Dependencies,
            AssetBundleInfos
        }

        public static AssetBundleManifest2 Load(string path)
        {
            if (!System.IO.File.Exists(path))
                return new AssetBundleManifest2();

            var lines = System.IO.File.ReadAllLines(path);

            var manifest = new AssetBundleManifest2();
            manifest.Name = System.IO.Path.GetFileNameWithoutExtension(path);
            manifest.Path = path;
            manifest.Assets = new List<string>(lines.Length);

            var category = Category.None;

            for (var n = 0; n < lines.Length; ++n)
            {
                var line = lines[n].Trim();
                if (string.IsNullOrEmpty(line))
                    continue;

                if (line.StartsWith("Assets:", System.StringComparison.OrdinalIgnoreCase))
                {
                    category = Category.Assets;
                    continue;
                }

                if (line.StartsWith("ClassTypes:", System.StringComparison.OrdinalIgnoreCase))
                {
                    category = Category.ClassTypes;
                    continue;
                }

                if (line.StartsWith("Dependencies:", System.StringComparison.OrdinalIgnoreCase))
                {
                    category = Category.Dependencies;
                    continue;
                }

                if (line.StartsWith("AssetBundleInfos:", System.StringComparison.OrdinalIgnoreCase))
                {
                    category = Category.AssetBundleInfos;
                    continue;
                }

                switch (category)
                {
                    case Category.Assets:
                        ReadAssets(lines, ref n, manifest);
                        break;

                    case Category.AssetBundleInfos:
                        ReadAssetBundleInfos(lines, ref n, manifest);
                        break;

                    case Category.Dependencies:
                        {
                            manifest.Dependencies.Add(line);
                        }
                        break;

                    default:
                        break;
                }
            }

            return manifest;
        }

        static void ReadAssetBundleInfos(string[] lines, ref int index, AssetBundleManifest2 target)
        {
            var info = 0;

            for (var n = index; n < lines.Length; ++n)
            {
                var line = lines[n].Trim();
                if (line.Length == 0)
                    break;

                var infoString = string.Format("Info_{0}:", info);
                if (string.Equals(infoString, line, System.StringComparison.OrdinalIgnoreCase))
                {
                    n++;
                    line = lines[n].Trim();
                    if (line.StartsWith("Name: ", System.StringComparison.OrdinalIgnoreCase))
                    {
                        target.Dependencies.Add(line.Substring("Name: ".Length));
                        info++;
                    }
                }

                index = n;
            }
        }

        static void ReadAssets(string[] lines, ref int index, AssetBundleManifest2 target)
        {
            for (var n = index; n < lines.Length; ++n)
            {
                var line = lines[n];
                if (line.Length == 0 || line[0] != '-')
                    break;

                // Each assets string look like this:
                // - Assets/Art/Aim/Guard_Aim_01_South.png
                // Get rid of the first 2 characters
                var value = line.Substring(2);//.Trim();
                target.Assets.Add(value);

                index = n;
            }
        }
    }
}