﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;

namespace EditorFramework
{
    public static class FileUtil2
    {
        #region GetFileExtension
        /// <summary>
        /// Returns the file-extension of the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path string from which to obtain the file extension.</param>
        public static string GetFileExtension(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return "";

            var index = assetPath.LastIndexOf('.');
            if (index != -1)
                return assetPath.Substring(index + 1);

            return "";
        }
        #endregion

        #region GetFileName
        /// <summary>
        /// Returns the file name and extension of the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path string from which to obtain the file name and extension.</param>
        /// <returns>
        /// A System.String consisting of the characters after the last directory character in path.
        /// If the last character of path is a directory or volume separator character, this method returns System.String.Empty.
        /// If path is null, this method returns null.
        /// </returns>
        public static string GetFileName(string assetPath)
        {
            // this method is pretty much just System.IO.Path.GetFileName,
            // but it won't thow an exception if an invalid path character is used.
            if (assetPath != null)
            {
                int length = assetPath.Length;
                int num2 = length;
                while (--num2 >= 0)
                {
                    char ch = assetPath[num2];
                    if (((ch == System.IO.Path.DirectorySeparatorChar) || (ch == System.IO.Path.AltDirectorySeparatorChar)) || (ch == System.IO.Path.VolumeSeparatorChar))
                    {
                        return assetPath.Substring(num2 + 1, (length - num2) - 1);
                    }
                }
            }
            return assetPath;

        }
        #endregion

        #region GetDirectoryName
        /// <summary>
        /// Returns the directory information of the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path string from which to obtain the file name without extension.</param>
        public static string GetDirectoryName(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return "";
            
            var directory = System.IO.Path.GetDirectoryName(assetPath);
            if (string.IsNullOrEmpty(directory))
                return "";

            directory = directory.Replace('\\', '/');
            return directory;
        }
        #endregion

        #region GetFileNameWithoutExtension
        /// <summary>
        /// Returns the filename without file-extension of the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path string from which to obtain the file name without extension.</param>
        public static string GetFileNameWithoutExtension(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return "";

            var filename = GetFileName(assetPath);
            var extindex = filename.LastIndexOf('.');
            if (extindex == -1)
                return filename;

            return filename.Substring(0, extindex);
        }
        #endregion

        #region Exists
        /// <summary>
        /// Determines whether the specified file exists.
        /// </summary>
        /// <param name="assetPath">The file to check.</param>
        /// <returns>true if the caller has the required permissions and path contains the name of an existing file; otherwise, false.</returns>
        public static bool Exists(string assetPath)
        {
            if (System.IO.File.Exists(assetPath))
                return true;

            return false;
        }
        #endregion

        #region IsReadOnly
        /// <summary>
        /// Returns whether the file specified by assetPath is read-only.
        /// </summary>
        /// <param name="assetPath">The asset path.</param>
        /// <returns>true when file is read-only, false otherwise.</returns>
        public static bool IsReadOnly(string assetPath)
        {
            if (!Exists(assetPath))
                return false;
            var info = new System.IO.FileInfo(assetPath);
            return info.IsReadOnly;
        }
        #endregion

        #region GetFileSize
        /// <summary>
        /// Gets the size, in bytes, of the specified file.
        /// </summary>
        /// <param name="assetPath">The file.</param>
        /// <returns>The size of the file in bytes on success, -1 otherwise.</returns>
        public static long GetFileSize(string assetPath)
        {
            try
            {
                return new System.IO.FileInfo(assetPath).Length;
            }
            catch (Exception)
            {
                // swallow exception
            }

            return -1;
        }
        #endregion
    }
}
