﻿//---------------------------------------
// Copyright (c) 2011-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace TextureOverview
{
    /// <summary>
    /// MainWindow represents the main application window of the plugin.
    /// </summary>
    public class MainWindow : EditorWindow2
    {
        #region Private Fields
        enum PickMode
        {
            Selection,
            Project,
            Scene,
            AssetBundleManifest
        }

        GUIToolbar _menu; // top toolbar menu
        GUIToolbar _bottommenu; // bottom toolbar menu
        Listbox _listview; // the actual list where all texture settings are displayed
        PickMode _pickmode = PickMode.Project;
        GUIToolbarLabel _platformlabel; // displays the active build target
        GUIToolbarLabel _searchlabel; // displays information about the current search/filter (eg 10 / 1000 textures displayed)
        GUIToolbarLabel _statslabel; // displays info about the current list selection
        GUIToolbarMenu _typemenu; // the 'Filter by Type' popup menu
        GUIToolbarButton _lockbutton; // in PickMode.Selection a buttton to lock the list content
        GUIToolbarSearchField _searchfield; // the control to enter a search text
        bool _locked; // whether the list content is locked
        TextureMemoryUsageOverlay _memoryUsage; // a reference to the memory usage overlay window
        AssetBundleManifestUI _manifestGUI;
        #endregion

        #region CreateWindow
        /// <summary>
        /// Called from TextureOverviewMenuItem.cs to create the window.
        /// This method checks if the plugin runs in the minimum required Unity version
        /// and displays a message in case it is not.
        /// </summary>
        public static EditorWindow CreateWindow()
        {
            var wnd = EditorWindow.GetWindow(typeof(MainWindow));
            wnd.title = Globals.ProductTitle;
            wnd.minSize = new Vector2(220, 90);
            return wnd;
        }
        #endregion

        #region OnCheckCompatibility
        /// <summary>
        /// Called before the window gets created.
        /// Checks if the plugin is compatible with the Unity version it is running in.
        /// </summary>
        protected override bool __OnCheckCompatibility()
        {
            if (!InstallerWindow.ValidateVersion(Globals.MinimumMajorVersion, Globals.MinimumMinorVersion,
                Globals.ProductTitle, Globals.ProductName, Globals.ProductFeedbackUrl))
                return false;

            return base.__OnCheckCompatibility();
        }
        #endregion

        #region OnCreate
        /// <summary>
        /// Called when the window gets created.
        /// This method creates all the controls.
        /// </summary>
        /// <remarks>
        /// Creation must be kept fast, otherwise the window gets displayed entirely white for a short moment.
        /// </remarks>
        protected override void __OnCreate()
        {
            // create the listview control
            _listview = new Listbox(this, null);
            _listview.EditorPrefsPath = string.Format("{0}.ListView", Globals.ProductId);
            _listview.LoadPrefs();
            _listview.EmptyText = "Loading texture importer settings. Please wait...";
            _listview.Platform = BuildPipeline2.GetBuildTargetGroupName(EditorUserBuildSettings.activeBuildTarget);
            _listview.PlatformGroup = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);

            // create a toolbar control
            _menu = new GUIToolbar(this, null);

            // create tools submenu
            var toolsmenu = _menu.AddMenu("Tools", "", null);
            toolsmenu.Add(new GUIToolbarMenuItem("Export as CSV...", OnToolsExportCsvExecute));
            toolsmenu.Add(new GUIToolbarMenuItem("Memory Usage", OnToolsMemoryUsageExecute, OnToolsMemoryUsageQuery));
            toolsmenu.Add(GUIToolbarMenuItem.Separator);
            toolsmenu.Add(new GUIToolbarMenuItem("Advanced/Handle Rgb24 as Rgba32 for graphics memory calculus", OnToolsGpuExpandRgb24ToRgba32Execute, OnToolsGpuExpandRgb24ToRgba32Query));

            // add the 'Pickmode' popup control to the toolbar
            _pickmode = (PickMode)EditorPrefs.GetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            var pickmodePopup = _menu.AddPopup("", "Select from where to list textures.", OnPickModeChange);
            pickmodePopup.Items = new[] { 
                new GUIToolbarPopupItem("Project", PickMode.Project),
                new GUIToolbarPopupItem("Scene", PickMode.Scene),
                new GUIToolbarPopupItem("Selection", PickMode.Selection),
#if UNITY_5
                new GUIToolbarPopupItem("AssetBundle Manifest", PickMode.AssetBundleManifest)
#endif
            };
            pickmodePopup.SelectTag(_pickmode);

            // add the lock button which is only visible when pickmode is set to Selection.
            _lockbutton = _menu.AddButton("", "Selection changes within the Unity Project or Hierachy window have no impact on the list when it is locked.", null, OnLockToggle, OnQueryLockToggle);
            _lockbutton.ImageSize = new Vector2(13, 13);
            SetLock(false);

            var refreshbutton = _menu.AddButton("Refresh", "Get new snapshot of all textures used by GameObjects at this moment.", Images.Refresh16x16, OnRefreshScene, OnQueryRefreshScene);
            refreshbutton.ImageSize = new Vector2(13, 13);

            // add the search field to the right side of the window
            _menu.AddSpace(8);
            _menu.AddFlexibleSpace();
            _searchfield = _menu.AddSearchField("", null, OnSearchChange, null);
            _searchfield.SearchModes = new[] { "Search in Name", "Search in Path" };
            _searchfield.SearchMode = EditorPrefs.GetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), 0);
            _searchfield.LayoutOptions = new[] { GUILayout.MinWidth(50), GUILayout.MaxWidth(5000), GUILayout.ExpandWidth(true) };
            _searchfield.AcceptDrop = true;

            // add the type filer dropdown
            _typemenu = _menu.AddMenu("", "Filter by Type", null);
            var types = new List<string>(new[] {
                TextureUtil2.TextureTypeStrings.Cookie,
                TextureUtil2.TextureTypeStrings.Cubemap,
                TextureUtil2.TextureTypeStrings.Image,
                TextureUtil2.TextureTypeStrings.GUI,
                TextureUtil2.TextureTypeStrings.Normalmap,
                TextureUtil2.TextureTypeStrings.Lightmap,
                TextureUtil2.TextureTypeStrings.Cursor,
                TextureUtil2.TextureTypeStrings.Reflection,
                TextureUtil2.TextureTypeStrings.Sprite});

            // sort types alphabetically and add them to the dropdown
            types.Sort(StringComparer.InvariantCultureIgnoreCase);
            foreach (var t in types)
            {
                var item = new GUIToolbarMenuItem(t, OnTypeFilterExecute, OnQueryTypeFilter);
                item.Tag = t;
                _typemenu.Add(item);
            }

            _typemenu.Add(GUIToolbarMenuItem.Separator); // separator
            _typemenu.Add(new GUIToolbarMenuItem("Reset Type Filter", OnTypeFilterResetExecute) { Tag = 1 });
            _typemenu.Image = EditorGUIUtility.FindTexture("FilterByType");
            if (null != _typemenu.Image)
                _typemenu.ImageSize = new Vector2(_typemenu.Image.width, _typemenu.Image.height);

            // add the button info bar
            _bottommenu = new GUIToolbar(this, null);

            _statslabel = _bottommenu.AddLabel();
            _bottommenu.AddFlexibleSpace();
            _searchlabel = _bottommenu.AddLabel();
            _searchlabel.Tooltip = "Count of textures in the list.";
            _platformlabel = _bottommenu.AddLabel();
            _platformlabel.ImageSize = new Vector2(13, 13);
            _bottommenu.AddButton("", "About Texture Overview.", Images.Info16x16, OnAboutExecute);
            
            // add some space at the right for the buttom menu.
            // this is especially important for OSX, where the window resize grabber is in the lower right corner of the window.
            // in order to prevent it to overlap with the info button, we simply add some space.
            _bottommenu.AddSpace(9);

            _memoryUsage = new TextureMemoryUsageOverlay();

#if UNITY_5
            _manifestGUI = new AssetBundleManifestUI();
            _manifestGUI.EditorPrefsPath = string.Format("{0}.AssetBundleManifest", Globals.ProductId);
            _manifestGUI.Init(this);
            _manifestGUI.SelectionChange = OnShowAssetBundleManifestContent;
#endif
        }
        #endregion

        #region OnDestroy
        /// <summary>
        /// Called when the window gets destroyed
        /// </summary>
        protected override void __OnDestroy()
        {
            if (_manifestGUI != null)
            {
                _manifestGUI.SelectionChange -= OnShowAssetBundleManifestContent;
                _manifestGUI.Destroy();
                _manifestGUI = null;
            }

            if (null != _listview)
            {
                _listview.Changed -= OnListboxChanged;
                _listview.TextureChanged -= OnListboxTextureChanged;
                _listview.SavePrefs();
                _listview.Dispose();
                _listview = null;
            }

            Images.OnDestroy();
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }
        #endregion

        #region OnInit
        /// <summary>
        /// Called after OnCreate and intented to initialize the plugin. This function is allowed to take longer.
        /// </summary>
        protected override void __OnInit()
        {
            _listview.ReadCacheFile();

            _listview.EmptyText = "The list is empty.";
            _listview.Changed += OnListboxChanged;
            _listview.TextureChanged += OnListboxTextureChanged;
            DoPickModeChange(_pickmode, true);

            if (_memoryUsage.Visible)
                UpdateMemoryUsage();
        }
        #endregion

        #region OnGUI
        /// <summary>
        /// Called periodically to handle and draw the UI.
        /// </summary>
        protected override void __OnGUI()
        {
            var targetgroup = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);

            _platformlabel.Text = BuildPipeline2.GetBuildTargetGroupDisplayName(targetgroup);
            _platformlabel.Image = BuildPipeline2.GetBuildTargetGroupImage(targetgroup) as Texture2D;
            _platformlabel.Tooltip = string.Format("Showing texture settings for platform:\n'{0}'\n\nChange platform in 'Build Settings' to display settings for another platform.", _platformlabel.Text);
            _listview.Platform = BuildPipeline2.GetBuildTargetGroupName(EditorUserBuildSettings.activeBuildTarget);
            _listview.PlatformGroup = targetgroup;
            _typemenu.Text = _listview.GetTypeFilterCount() > 0 ? "!" : "";

            BeginWindows();

            EditorGUILayout.BeginHorizontal();

            if (_manifestGUI != null && _pickmode == PickMode.AssetBundleManifest)
                _manifestGUI.OnGUI();

            EditorGUILayout.BeginVertical();
            _menu.OnGUI();
            _listview.OnGUI();
            EditorGUILayout.EndVertical();

            EditorGUILayout.EndHorizontal();

            _bottommenu.OnGUI();

            if (_memoryUsage != null)
                _memoryUsage.OnGUI(this);

            EndWindows();
        }
        #endregion

        #region OnFindCommand
        /// <summary>
        /// Called when the user invoked the find command (Ctrl+F).
        /// </summary>
        protected override void __OnFindCommand()
        {
            _searchfield.Focus();
        }
        #endregion

        #region OnLockToggle
        /// <summary>
        /// Called when the user clicked the Lock button.
        /// </summary>
        /// <remarks>The Lock button is available in Selection PickMode only.</remarks>
        void OnLockToggle(GUIControl sender)
        {
            SetLock(!_locked);
        }

        /// <summary>
        /// Gets the UI status of the Lock button.
        /// </summary>
        GUIControlStatus OnQueryLockToggle(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Selection)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }

        /// <summary>
        /// Locks/Unlocks the Selection PickMode.
        /// </summary>
        /// <param name="locked">true to lock, false to unlock.</param>
        void SetLock(bool locked)
        {
            if (locked)
            {
                _lockbutton.Image = Images.Lock16x16;
                _lockbutton.Text = "Unlock";
            }
            else
            {
                _lockbutton.Image = Images.Unlock16x16;
                _lockbutton.Text = "Lock";
            }

            _locked = locked;
        }
        #endregion

        #region OnRefreshScene
        /// <summary>
        /// Called when the user pressed the Refresh button.
        /// </summary>
        /// <remarks>The Refresh button is available in Scene PickMode only.</remarks>
        void OnRefreshScene(GUIControl sender)
        {
            DoPickModeChange(PickMode.Scene, true);
            Repaint();
        }

        /// <summary>
        /// Gets the UI status of the Refresh button.
        /// </summary>
        GUIControlStatus OnQueryRefreshScene(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Scene)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }
        #endregion

        #region OnToolsExportCsv
        /// <summary>
        /// Exports the listbox content as CSV.
        /// </summary>
        void OnToolsExportCsvExecute(GUIToolbarMenuItem sender)
        {
            _listview.SaveCsv();
        }
        #endregion

        #region OnToolsMemoryUsage
        /// <summary>
        /// Opens the Memory Usage window.
        /// </summary>
        void OnToolsMemoryUsageExecute(GUIToolbarMenuItem sender)
        {
            _memoryUsage.Visible = !_memoryUsage.Visible;
            if (_memoryUsage.Visible)
                UpdateMemoryUsage();
        }

        GUIControlStatus OnToolsMemoryUsageQuery(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (_memoryUsage.Visible)
                result |= GUIControlStatus.Checked;
            return result;
        } 
        #endregion

        #region OnToolsGpuExpandRgb24ToRgba32
        /// <summary>
        /// Toggle the GpuExpandRgb24ToRgba32 option.
        /// </summary>
        void OnToolsGpuExpandRgb24ToRgba32Execute(GUIToolbarMenuItem sender)
        {
            Globals.GpuExpandRgb24ToRgba32 = !Globals.GpuExpandRgb24ToRgba32;           
            _listview.RecalcMemoryUsage();
        }

        GUIControlStatus OnToolsGpuExpandRgb24ToRgba32Query(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (Globals.GpuExpandRgb24ToRgba32)
                result |= GUIControlStatus.Checked;
            return result;
        }
        #endregion

        #region OnAbout
        /// <summary>
        /// Called when the user clicked the About button.
        /// </summary>
        void OnAboutExecute(GUIControl sender)
        {
            var wnd = AboutWindow.GetWindow<AboutWindow>(true, "About " + Globals.ProductTitle, true);
            wnd.ProductName = Globals.ProductName;
            wnd.FeedbackUrl = Globals.ProductFeedbackUrl;
            wnd.AssetStoreUrl = Globals.ProductAssetStoreUrl;
            wnd.Show();
        }
        #endregion

        #region OnListboxChanged
        /// <summary>
        /// Called when the listbox changed.
        /// </summary>
        void OnListboxChanged(GUIListView sender)
        {
            _searchlabel.Text = _listview.ItemCountString + " |";
            _statslabel.Text = _listview.SelectionString;
            UpdateMemoryUsage();
        }
        #endregion

        #region OnListboxTextureChanged
        /// <summary>
        /// Called when texture properties of an item inside the listbox changed.
        /// </summary>
        void OnListboxTextureChanged(GUIListView sender)
        {
            UpdateMemoryUsage();
        }

        /// <summary>
        /// Gets the current memory usage of textures shown in listbox.
        /// </summary>
        void UpdateMemoryUsage()
        {
            if (!_memoryUsage.Visible)
                return;

            _listview.GetMemoryUsage(out _memoryUsage.CpuUsage, out _memoryUsage.GpuUsage, out _memoryUsage.RuntimeUsage, out _memoryUsage.StorageUsage);
            Repaint();
        }
        #endregion

        #region OnSearchChange
        /// <summary>
        /// Called when the search text or type changed.
        /// </summary>
        void OnSearchChange(GUIControl sender)
        {
            var searchfield = (GUIToolbarSearchField)sender;
            EditorPrefs.SetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), searchfield.SearchMode);
            _listview.SetTextFilter(searchfield.Text, (Listbox.TextFilterMode)searchfield.SearchMode);

            if (_listview.ItemCount == 0 && !string.IsNullOrEmpty(sender.Text))
                _listview.EmptyText = "No match found. Proper search mode used?\n\nYou can choose the search mode using the magnifying glass next to the search field.\nYou can drop files and folders on the search field.\nYou can use search operators like: && (and) || (or) and ! (not)";
            else
                _listview.EmptyText = "The list is empty.";
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Called when the listbox selection changed.
        /// </summary>
        void OnSelectionChange()
        {
            if (_listview == null)
                return;

            // I'm not really happy with this line of code, particulary with the 'ChangeUnitySelectionTime'.
            // it makes sure that the OnSelectionChange() call only has an impact when any selection change
            // caused by the list is more than 0.5 seconds ago. without this line of code, the plugin most
            // likely ends up in an infinite loop when being in PickMode.Selection, because if the list assigns
            // the selection unity triggers OnSelectionChange() and without the 0.5sec delay the selection is
            // assigned to the list immediately and OnSelectionChange() is called again etc.
            if (_pickmode != PickMode.Selection || _locked || _listview.ChangeUnitySelectionTime + 0.5f > DateTime.Now.TimeOfDay.TotalSeconds)// || selection.Length == 0)
                return;

            // get the current selection
            var selection = Selection.objects;

            var paths = new List<string>();
            selection = EditorUtility.CollectDependencies(selection);

            // get all textures from selection
            var selectionpaths = new List<string>();
            foreach (var obj in selection)
            {
                if (obj is Texture)
                {
                    var path = AssetDatabase.GetAssetPath(obj);
                    if (!string.IsNullOrEmpty(path))
                        paths.Add(path);
                }
            }

            // now paths only contains paths of textures
            _listview.SetItems(paths);

            UpdateMemoryUsage();
        }
        #endregion

        void OnShowAssetBundleManifestContent(List<AssetBundleManifest2> manifests)
        {
            var assets = new List<string>();
            foreach (var manifest in manifests)
                assets.AddRange(manifest.Assets);

            _listview.SetItems(assets);
        }

        #region OnPickModeChange
        /// <summary>
        /// Called when the pick mode (Project, Scene, Selection) changed.
        /// </summary>
        void OnPickModeChange(GUIControl sender)
        {
            var popup = (GUIToolbarPopup)sender;

            SetLock(false);
            _pickmode = (PickMode)popup.SelectedItem.Tag;
            EditorPrefs.SetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            DoPickModeChange(_pickmode, false);
        }

        void DoPickModeChange(PickMode newpickmode, bool checkTimeStamp)
        {
            switch (newpickmode)
            {
                case PickMode.AssetBundleManifest:
                    _listview.SetItems(new List<string>());
                    break;

                case PickMode.Selection:
                    _listview.SetItems(new List<string>());
                    OnSelectionChange();
                    break;

                case PickMode.Scene:
                    {
                        var deps = new List<UnityEngine.Object>(EditorUtility.CollectDependencies(EditorUtility2.GetSceneRootObjects().ToArray()));

                        // If a skybox is assigned, make sure to add it to the list
                        if (RenderSettings.skybox != null)
                            deps.AddRange(EditorUtility.CollectDependencies(new[] { RenderSettings.skybox }));

                        var paths = new List<string>(128);
                        foreach (var obj in deps)
                        {
                            if (!(obj is Texture))
                                continue; // we're interested in textures only

                            var path = AssetDatabase.GetAssetPath(obj);
                            if (!string.IsNullOrEmpty(path))
                                paths.Add(path);
                        }

                        _listview.SetItems(paths);
                    }
                    break;

                case PickMode.Project:
                    _listview.SetItems(new List<string>(AssetDatabase.GetAllAssetPaths()));
                    break;
            }

            UpdateMemoryUsage();
        }
        #endregion

        #region OnTypeFilter
        /// <summary>
        /// Called when the user changed the texture type filter.
        /// </summary>
        void OnTypeFilterExecute(GUIToolbarMenuItem sender)
        {
            _listview.BeginChangeFilter();
            try
            {
                var name = sender.Tag as string;

                // toggle filter
                if (_listview.HasTypeFilter(name))
                    _listview.RemoveTypeFilter(name);
                else
                    _listview.AddTypeFilter(name);
            }
            finally
            {
                _listview.EndChangeFilter();
            }
        }

        /// <summary>
        /// Gets the UI status of one type filter item.
        /// </summary>
        GUIControlStatus OnQueryTypeFilter(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible | GUIControlStatus.Enable;
            if (_listview.HasTypeFilter(sender.Tag as string))
                result |= GUIControlStatus.Checked;

            return result;
        }

        /// <summary>
        /// Called when the user clicked the Reset Type Filter item.
        /// </summary>
        void OnTypeFilterResetExecute(GUIToolbarMenuItem sender)
        {
            _listview.ClearTypeFilter();
        }
        #endregion
    }
}
