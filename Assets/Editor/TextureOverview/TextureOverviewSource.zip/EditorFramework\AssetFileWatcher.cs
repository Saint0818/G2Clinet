﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Listens to asset-pipeline notifications and raises events when an asset has been imported, moved or deleted.
    /// </summary>
    public class AssetFileWatcher : AssetPostprocessor
    {
        /// <summary>
        /// Occurs when an asset has been imported.
        /// </summary>
        public static event Action<string[]> Imported;
        
        /// <summary>
        /// Occurs when an asset has been deleted.
        /// </summary>
        public static event Action<string[]> Deleted;

        /// <summary>
        /// Occurs when an asset has been moved.
        /// </summary>
        public static event Action<string[], string[]> Moved;

        // whether to log asset pipeline notifications for debug purposes.
        public static bool LogEnabled;

        static void LogIt(string title, string[] list)
        {
            Debug.Log(title);
            if (null != list)
            {
                foreach (var s in list)
                    Debug.Log(s);
            }
        }

        #region OnPostprocessAllAssets
        /// <summary>
        /// Called by the unity asset-pipeline.
        /// </summary>
        static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromPath)
        {
            if (null != deletedAssets && deletedAssets.Length > 0)
            {
                if (LogEnabled) 
                    LogIt("AssetFileWatcher.Deleted", deletedAssets);

                if (null != Deleted)
                    Deleted.Invoke(deletedAssets);
            }

            if (null != movedFromPath && movedFromPath.Length > 0)
            {
                if (LogEnabled)
                    LogIt("AssetFileWatcher.Moved", movedAssets);

                if (null != Moved)
                    Moved.Invoke(movedFromPath, movedAssets);
            }

            if (null != importedAssets && importedAssets.Length > 0)
            {
                if (LogEnabled)
                    LogIt("AssetFileWatcher.Imported", importedAssets);

                if (null != Imported)
                    Imported.Invoke(importedAssets);
            }
        }
        #endregion
    }
}
