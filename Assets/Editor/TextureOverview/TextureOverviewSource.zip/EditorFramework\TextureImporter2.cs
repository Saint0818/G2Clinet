﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class TextureImporterPlatformSetting
    {
        /// <summary>
        /// The maximum texture size in pixels.
        /// </summary>
        public int MaxTextureSize;

        /// <summary>
        /// The texture format.
        /// </summary>
        public TextureImporterFormat TextureFormat;

        /// <summary>
        /// The compression quality in range 0..100
        /// </summary>
        public int CompressionQuality;

        /// <summary>
        /// Whether any setting has been overriden.
        /// </summary>
        public bool Overridden;

        /// <summary>
        /// Indicates whether the MaxTextureSize has been overridden for the platform.
        /// </summary>
        public bool MaxTextureSizeOverridden;

        /// <summary>
        /// Indicates whether the TextureFormat has been overridden for the platform.
        /// </summary>
        public bool TextureFormatOverridden;

        /// <summary>
        /// Indicates whether the CompressionQuality has been overridden for the platform.
        /// </summary>
        public bool CompressionQualityOverridden;
    }

    /// <summary>
    /// TextureImporter2 provides various methods to read properties of a TextureImporter.
    /// </summary>
    /// <remarks>
    /// Some methods are actually available in UnityEditor.TextureImporter, but they are not public in there.
    /// </remarks>
    public static class TextureImporter2
    {
        #region Private Fields
        static Type _type;
        static MethodInfo _getWidthAndHeight;
        #endregion

        #region ctor
        static TextureImporter2()
        {
            _type = typeof(TextureImporter).Assembly.GetType("UnityEditor.TextureImporter");
            if (_type != null)
            {
                _getWidthAndHeight = _type.GetMethod("GetWidthAndHeight", BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(int).MakeByRefType(), typeof(int).MakeByRefType() }, null);
            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'TextureImporter'.");

            if (null == _getWidthAndHeight)
                Debug.LogWarning("Could not find method 'TextureImporter.GetWidthAndHeight(ref int, ref int)'.");
        }
        #endregion

        #region GetWidthAndHeight
        /// <summary>
        /// Gets the width and height of the source texture asset.
        /// </summary>
        /// <param name="importer">The TextureImporter</param>
        /// <param name="width">The output width</param>
        /// <param name="height">The output height</param>
        public static void GetWidthAndHeight(TextureImporter importer, ref int width, ref int height)
        {
            if (null == _getWidthAndHeight)
                return;

            var args = new object[] { width, height };
            _getWidthAndHeight.Invoke(importer, args);
            width = (int)args[0];
            height = (int)args[1];
        }
        #endregion

        #region IsNormalMap
        /// <summary>
        /// Gets whether the texture of the specified importer is imported as a normalmap.
        /// </summary>
        /// <param name="importer">The TextureImporter</param>
        /// <returns>true when it gets imported as normalmap, false otherwise.</returns>
        public static bool IsNormalMap(TextureImporter importer)
        {
            if (null == importer)
                return false;
           
            switch (importer.textureType)
            {
                case TextureImporterType.Advanced:
                    return importer.normalmap;

                case TextureImporterType.Bump:
                    return true;
            }

            return false;
        }
        #endregion

        #region GetTexturePlatformSetting
        /// <summary>
        /// Gets the platform texture settings for the texture of the specified importer and platform.
        /// </summary>
        /// <param name="importer">The TextureImporter</param>
        /// <param name="platform">The platform name, as returned by BuildPipeline2.GetBuildTargetGroupName().</param>
        /// <returns></returns>
        public static TextureImporterPlatformSetting GetTexturePlatformSetting(TextureImporter importer, string platform)
        {
            var result = new TextureImporterPlatformSetting();
            if (platform == null)
                platform = "Default";

            if (importer == null)
                return result;

            if (string.Equals(platform, "Default", StringComparison.OrdinalIgnoreCase))
            {
                result.MaxTextureSize = importer.maxTextureSize;
                result.TextureFormat = importer.textureFormat;
                result.CompressionQuality = importer.compressionQuality;
            }
            else
            {
                importer.GetPlatformTextureSettings(platform,
                    out result.MaxTextureSize, out result.TextureFormat, out result.CompressionQuality);
            }

            result.MaxTextureSizeOverridden = importer.maxTextureSize != result.MaxTextureSize;
            result.TextureFormatOverridden = importer.textureFormat != result.TextureFormat;
            result.CompressionQualityOverridden = importer.compressionQuality != result.CompressionQuality;
            result.Overridden = result.MaxTextureSizeOverridden || result.TextureFormatOverridden || result.CompressionQualityOverridden;

            return result;
        }
        #endregion
    }
}
