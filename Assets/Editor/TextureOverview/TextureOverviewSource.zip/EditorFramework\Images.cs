﻿using System;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Images provides various textures that are commonly needed.
    /// </summary>
    /// <remarks>
    /// Texture data is stored as source code and lazy-transformed into a Texture2D on first access.
    /// Having the texture not as an external asset has various advantages: easier deployment of plugins,
    /// more robust because the user cannot delete an required image and the textures won't appear in the Unity
    /// texture picker dialog.
    /// 
    /// You can convert a texture into 'pixel data' using the method TextureUtil2.ToSourceCode().
    /// </remarks>
    static public class Images
    {
        #region Private Fields
        static System.Collections.Generic.List<Texture2D> _createdTextures = new System.Collections.Generic.List<Texture2D>();

        // if you add a new texture, do not forget to set its reference to null in OnPluginDestroy.
        static Texture2D _darkchessboard;
        static Texture2D _warningsmall;
        static Texture2D _infosmall;
        static Texture2D _errorsmall;
        static Texture2D _rgbchannel;
        static Texture2D _alphachannel;
        static Texture2D _audiofile;
        static Texture2D _compressedaudiofile;
        static Texture2D _accept;
        static Texture2D _acceptPressed;
        static Texture2D _revert;
        static Texture2D _revertPressed;
        static Texture2D _lock;
        static Texture2D _unlock;
        static Texture2D _next;
        static Texture2D _nextPressed;
        static Texture2D _refresh;
        static Texture2D _texture2D;
        static Texture2D _cubemap;
        static Texture2D _shadersmall;
        static Texture2D _builtinshadersmall;
        static Texture2D _cancelsmall;
        static Texture2D _cancelsmallPressed;
        static Texture2D _hiddensmall;
        static Texture2D _assetbundlesmall;
        #endregion

        #region OnDestroy
        /// <summary>
        /// Called when the plugin is about to get destroyed.
        /// </summary>
        public static void OnDestroy()
        {
            foreach (var texture in _createdTextures)
            {
                if (null != texture)
                    Texture.DestroyImmediate(texture);
            }
            _createdTextures.Clear();

            _shadersmall = null;
            _builtinshadersmall = null;
            _darkchessboard = null;
            _warningsmall = null;
            _infosmall = null;
            _errorsmall = null;
            _rgbchannel = null;
            _alphachannel = null;
            _audiofile = null;
            _compressedaudiofile = null;
            _accept = null;
            _acceptPressed = null;
            _revert = null;
            _revertPressed = null;
            _lock = null;
            _unlock = null;
            _refresh = null;
            _next = null;
            _nextPressed = null;
            _texture2D = null;
            _cubemap = null;
            _hiddensmall = null;
            _assetbundlesmall = null;
        }
        #endregion

        #region AssetBundle16x16
        /// <summary>
        /// Gets the shader icon.
        /// </summary>
        public static Texture2D AssetBundle16x16
        {
            get
            {
                if (null == _assetbundlesmall)
                    _assetbundlesmall = Create("AssetBundle16x16", _assetbundleData16x16, 16, 16);

                return _assetbundlesmall;
            }
        }
        #endregion

        #region Hidden16x16
        /// <summary>
        /// Gets the shader icon.
        /// </summary>
        public static Texture2D Hidden16x16
        {
            get
            {
                if (null == _hiddensmall)
                    _hiddensmall = Create("Hidden16x16", _hiddenData16x16, 16, 16);

                return _hiddensmall;
            }
        }
        #endregion

        #region Cancel16x16
        /// <summary>
        /// Gets the shader icon.
        /// </summary>
        public static Texture2D Cancel16x16
        {
            get
            {
                if (null == _cancelsmall)
                    _cancelsmall = CreateAlpha("Cancel16x16", new Color32(140, 140, 140, 255), _cancelData16x16, 14, 14);

                return _cancelsmall;
            }
        }

        public static Texture2D CancelPressed16x16
        {
            get
            {
                if (null == _cancelsmallPressed)
                   // _cancelsmallPressed = CreatePressed("CancelPressed16x16", _cancelData16x16, 14, 14);
                    _cancelsmallPressed = CreateAlpha("CancelPressed16x16", new Color32(200, 200, 200, 255), _cancelData16x16, 14, 14);
                return _cancelsmallPressed;
            }
        }
        #endregion

        #region Shader16x16
        /// <summary>
        /// Gets the shader icon.
        /// </summary>
        public static Texture2D Shader16x16
        {
            get
            {
                if (null == _shadersmall)
                    _shadersmall = Create("Shader16x16", _shaderData16x16, 16, 16);

                return _shadersmall;
            }
        }
        #endregion

        #region BuiltinShader16x16
        /// <summary>
        /// Gets the shader icon.
        /// </summary>
        public static Texture2D BuiltinShader16x16
        {
            get
            {
                if (null == _builtinshadersmall)
                    _builtinshadersmall = Create("BuiltinShader16x16", _builtinShaderData16x16, 16, 16);

                return _builtinshadersmall;
            }
        }
        #endregion

        #region Unity Icon: Texture2D16x16
        /// <summary>
        /// Gets the Unity built-in icon of a Texture2D asset.
        /// </summary>
        public static Texture2D Texture2D16x16
        {
            get
            {
                if (null == _texture2D)
                    _texture2D = UnityEditor.AssetPreview.GetMiniTypeThumbnail(typeof(Texture2D));

                return _texture2D;
            }
        }
        #endregion

        #region Unity Icon: Cubemap16x16
        /// <summary>
        /// Gets the Unity built-in icon of a Cubemap asset.
        /// </summary>
        public static Texture2D Cubemap16x16
        {
            get
            {
                if (null == _cubemap)
                    _cubemap = UnityEditor.AssetPreview.GetMiniTypeThumbnail(typeof(Cubemap));

                return _cubemap;
            }
        }
        #endregion

        #region Refresh16x16
        public static Texture2D Refresh16x16
        {
            get
            {
                if (null == _refresh)
                    _refresh = Create("Refresh16x16", _refreshData16x16, 16, 16);
                return _refresh;
            }
        }
        #endregion

        #region Next16x16
        public static Texture2D Next16x16
        {
            get
            {
                if (null == _next)
                    _next = Create("Next16x16", _nextClosedData16x16, 16, 16);
                return _next;
            }
        }

        public static Texture2D NextPressed16x16
        {
            get
            {
                if (null == _nextPressed)
                    _nextPressed = CreatePressed("NextPressed16x16", _nextClosedData16x16, 16, 16);
                return _nextPressed;
            }
        }
        #endregion

        #region Lock16x16
        public static Texture2D Lock16x16
        {
            get
            {
                if (null == _lock)
                    _lock = Create("Lock16x16", _lockIconData16x16, 16, 16);
                return _lock;
            }
        }
        #endregion

        #region Unlock16x16
        public static Texture2D Unlock16x16
        {
            get
            {
                if (null == _unlock)
                    _unlock = Create("Unlock16x16", _unlockIconData16x16, 16, 16);
                return _unlock;
            }
        }
        #endregion

        #region Revert16x16
        public static Texture2D Revert16x16
        {
            get
            {
                if (null == _revert)
                    _revert = Create("Revert16x16", _revertIconData16x16, 16, 16);
                return _revert;
            }
        }

        public static Texture2D RevertPressed16x16
        {
            get
            {
                if (null == _revertPressed)
                    _revertPressed = CreatePressed("RevertPressed16x16", _revertIconData16x16, 16, 16);
                return _revertPressed;
            }
        }
        #endregion

        #region Accept16x16
        public static Texture2D Accept16x16
        {
            get
            {
                if (null == _accept)
                    _accept = Create("Accept16x16", _acceptIconData16x16, 16, 16);
                return _accept;
            }
        }

        public static Texture2D AcceptPressed16x16
        {
            get
            {
                if (null == _acceptPressed)
                    _acceptPressed = CreatePressed("AcceptPressed16x16", _acceptIconData16x16, 16, 16);
                return _acceptPressed;
            }
        }
        #endregion

        #region AudioFile16x16
        /// <summary>
        /// Gets the icon of an uncompressed audio file.
        /// </summary>
        public static Texture2D AudioFile16x16
        {
            get
            {
                if (null == _audiofile)
                    _audiofile = Create("AudioFile16x16", _audioFileData, 16, 16);
                return _audiofile;
            }
        }
        #endregion

        #region CompressedAudioFile16x16
        /// <summary>
        /// Gets the icon of a compressed audio file.
        /// </summary>
        public static Texture2D CompressedAudioFile16x16
        {
            get
            {
                if (null == _compressedaudiofile)
                    _compressedaudiofile = Create("CompressedAudioFile16x16", _compressedAudioFileData, 16, 16);
                return _compressedaudiofile;
            }
        }
        #endregion

        #region Unity Icon: RgbChannel16x16
        /// <summary>
        /// Gets the Unity built-in RGB channel icon.
        /// </summary>
        public static Texture2D RgbChannel16x16
        {
            get
            {
                if (null == _rgbchannel)
                {
                    _rgbchannel = EditorGUIUtility2.LoadIcon("PreTextureRGB");
                    if (null == _rgbchannel)
                        _rgbchannel = EditorGUIUtility.whiteTexture;
                }

                return _rgbchannel;
            }
        }
        #endregion

        #region Unity Icon: AlphaChannel16x16
        /// <summary>
        /// Gets the Unity built-in alpha channel icon.
        /// </summary>
        public static Texture2D AlphaChannel16x16
        {
            get
            {
                if (null == _alphachannel)
                {
                    _alphachannel = EditorGUIUtility2.LoadIcon("PreTextureAlpha");
                    if (null == _alphachannel)
                        _alphachannel = EditorGUIUtility.whiteTexture;
                }

                return _alphachannel;
            }
        }
        #endregion

        #region Unity Icon: Warning16x16
        /// <summary>
        /// Gets the Unity built-in warning icon as used in the Console window.
        /// </summary>
        public static Texture2D Warning16x16
        {
            get
            {
                if (null == _warningsmall)
                {
                    _warningsmall = EditorGUIUtility2.LoadIcon("console.warnicon.sml");
                    if (null == _warningsmall)
                        _warningsmall = EditorGUIUtility.whiteTexture;
                }

                return _warningsmall;
            }
        }
        #endregion

        #region Unity Icon: Info16x16
        /// <summary>
        /// Gets the Unity built-in info icon as used in the Console window.
        /// </summary>
        public static Texture2D Info16x16
        {
            get
            {
                if (null == _infosmall)
                {
                    _infosmall = EditorGUIUtility2.LoadIcon("console.infoicon.sml");
                    if (null == _infosmall)
                        _infosmall = EditorGUIUtility.whiteTexture;
                }

                return _infosmall;
            }
        }
        #endregion

        #region Unity Icon: Error16x16
        /// <summary>
        /// Gets the Unity built-in error icon as used in the Console window.
        /// </summary>
        public static Texture2D Error16x16
        {
            get
            {
                if (null == _errorsmall)
                {
                    _errorsmall = EditorGUIUtility2.LoadIcon("console.erroricon.sml");
                    if (null == _errorsmall)
                        _errorsmall = EditorGUIUtility.whiteTexture;
                }

                return _errorsmall;
            }
        }
        #endregion

        #region DarkChessboard32x32
        /// <summary>
        /// Gets a dark gray checkerboard/chessboard image.
        /// </summary>
        public static Texture2D DarkChessboard32x32
        {
            get
            {
                if (null == _darkchessboard)
                {
                    const int size = 32;
                    const int halfsize = size/2;

                    var color1 = new Color(49.0f / 255.0f, 49.0f / 255.0f, 49.0f / 255.0f, 1.0f);
                    var color2 = new Color(55.0f / 255.0f, 55.0f / 255.0f, 55.0f / 255.0f, 1.0f);
                    var colors = new Color[] { color1, color2 };

                    var z = 0;
                    var data = new Color[size * size];
                    for (var x = 0; x < size; x += halfsize)
                    {
                        for (var y = 0; y < size; y += halfsize)
                        {
                            for (var xx = 0; xx < halfsize; ++xx)
                                for (var yy = 0; yy < halfsize; ++yy)
                                    data[(x + xx) + size*(y + yy)] = colors[z & 1];
                            
                            z++;
                        }
                        z++;
                    }

                    _darkchessboard = new Texture2D(size, size, TextureFormat.RGBA32, false, true);
                    _darkchessboard.hideFlags = HideFlags.HideAndDontSave;
                    _darkchessboard.SetPixels(data);
                    _darkchessboard.Apply();
                }
                return _darkchessboard;
            }
        }
        #endregion

        #region CreatePressed
        /// <summary>
        /// Creates a darker texture of the specified data.
        /// </summary>
        /// <param name="data">The array of Color32 elements describing the pixels of the texture.</param>
        /// <param name="width">The texture width.</param>
        /// <param name="height">The texture height.</param>
        /// <returns>The created texture.</returns>
        static Texture2D CreatePressed(string name, Color32[] data, int width, int height)
        {
            var ar = new Color32[data.Length];
            Array.Copy(data, ar, data.Length);
            for (var n = 0; n < ar.Length; ++n)
                ar[n] = new Color32((byte)(ar[n].r / 1.5f), (byte)(ar[n].g / 1.5f), (byte)(ar[n].b / 1.5f), ar[n].a);
            return Create(name, ar, width, height);
        }
        #endregion

        #region Create
        /// <summary>
        /// Creates a texture of the specified data.
        /// </summary>
        /// <param name="data">The array of Color32 elements describing the pixels of the texture.</param>
        /// <param name="width">The texture width.</param>
        /// <param name="height">The texture height.</param>
        /// <returns>The created texture.</returns>
        static Texture2D Create(string name, Color32[] data, int width, int height)
        {
            var texture = new Texture2D(width, height, TextureFormat.ARGB32, true, true);
            texture.name = "EditorFramework-" + name;
            _createdTextures.Add(texture);

            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.SetPixels32(data);
            texture.Apply();
            return texture;
        }

        static Texture2D CreateAlpha(string name, Color32 rgb, Color32[] alpha, int width, int height)
        {
            var texture = new Texture2D(width, height, TextureFormat.ARGB32, true, true);
            texture.name = "EditorFramework-" + name;
            _createdTextures.Add(texture);

            var data2 = new Color32[alpha.Length];
            for (var n = 0; n < alpha.Length; ++n)
                data2[n] = new Color32(rgb.r, rgb.b, rgb.b, alpha[n].a);

            texture.hideFlags = HideFlags.HideAndDontSave;
            texture.SetPixels32(data2);
            texture.Apply();
            return texture;
        }
        #endregion

        #region Pixel Data
        #region AssetBundle
        readonly static Color32[] _assetbundleData16x16 = new Color32[] {
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
         new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(130,153,172,255),
         new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(31,31,31,255), new Color32(103,103,103,255),
         new Color32(220,220,220,255), new Color32(254,254,254,255), new Color32(254,254,254,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255),
         new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(18,18,18,255), new Color32(91,91,91,255), new Color32(249,249,249,255), new Color32(255,255,255,255), new Color32(255,255,255,255),
         new Color32(223,223,223,255), new Color32(32,32,32,255), new Color32(79,79,79,255), new Color32(250,250,250,255), new Color32(153,174,195,255), new Color32(153,174,195,255),
         new Color32(50,50,50,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(18,18,18,255), new Color32(87,87,87,255),
         new Color32(248,248,248,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(252,252,252,255), new Color32(103,103,103,255), new Color32(26,26,26,255),
         new Color32(211,211,211,255), new Color32(254,254,254,255), new Color32(62,62,62,255), new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(17,17,17,255), new Color32(28,28,28,255), new Color32(120,120,120,255), new Color32(129,129,128,255), new Color32(130,130,129,255),
         new Color32(130,130,130,255), new Color32(121,121,121,255), new Color32(31,31,31,255), new Color32(119,119,119,255), new Color32(254,254,254,255), new Color32(255,255,255,255),
         new Color32(153,174,195,255), new Color32(153,174,195,255), new Color32(50,50,50,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(20,20,20,255),
         new Color32(23,23,23,255), new Color32(26,26,26,255), new Color32(29,29,29,255), new Color32(32,32,32,255), new Color32(33,33,33,255), new Color32(34,34,34,255),
         new Color32(35,35,35,255), new Color32(176,176,176,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(62,62,62,255), new Color32(113,137,157,255),
         new Color32(153,174,195,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(37,38,38,255), new Color32(36,36,36,255), new Color32(178,178,178,255),
         new Color32(243,243,243,255), new Color32(244,244,244,255), new Color32(244,244,244,255), new Color32(243,243,243,255), new Color32(100,100,100,255), new Color32(72,72,72,255),
         new Color32(244,244,244,255), new Color32(255,255,255,255), new Color32(153,174,195,255), new Color32(153,174,195,255), new Color32(50,50,50,255), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(47,47,48,255), new Color32(49,49,49,255), new Color32(193,193,193,255), new Color32(254,254,254,255),
         new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(176,176,176,255), new Color32(48,48,48,255), new Color32(154,154,154,255), new Color32(252,252,252,255),
         new Color32(62,62,62,255), new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(58,58,59,255), new Color32(62,62,62,255), new Color32(208,208,208,255), new Color32(254,254,254,255), new Color32(255,255,255,255),
         new Color32(252,252,252,255), new Color32(95,95,95,255), new Color32(62,62,62,255), new Color32(255,255,255,255), new Color32(153,174,195,255), new Color32(153,174,195,255),
         new Color32(50,50,50,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(62,62,62,255), new Color32(62,62,62,255), new Color32(129,129,129,255), new Color32(175,175,175,255), new Color32(222,222,222,255), new Color32(202,202,202,255),
         new Color32(55,55,55,255), new Color32(77,77,76,255), new Color32(62,62,62,255), new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(62,62,62,255),
         new Color32(62,62,62,255), new Color32(80,80,80,255), new Color32(76,76,76,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
         new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
         new Color32(130,153,172,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255),
         new Color32(181,210,235,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
        };
        #endregion

        #region Cancel
        readonly static Color32[] _cancelData16x16 = new Color32[] {
         new Color32(148,148,148,0), new Color32(131,131,131,0), new Color32(94,94,93,0), new Color32(99,99,99,6), new Color32(82,82,82,97), new Color32(73,73,73,173),
         new Color32(68,68,68,207), new Color32(68,68,68,209), new Color32(71,71,71,181), new Color32(78,78,78,110), new Color32(83,83,83,16), new Color32(88,88,88,0),
         new Color32(124,124,124,0), new Color32(149,149,149,0), new Color32(148,148,148,0), new Color32(133,133,133,0), new Color32(87,87,87,51), new Color32(77,77,77,210),
         new Color32(62,62,62,255), new Color32(63,63,63,255), new Color32(63,63,63,255), new Color32(63,63,63,255), new Color32(63,63,63,255), new Color32(63,63,63,255),
         new Color32(68,68,68,222), new Color32(82,82,81,75), new Color32(126,126,126,0), new Color32(149,149,149,0), new Color32(149,149,149,0), new Color32(126,126,126,41),
         new Color32(65,65,65,236), new Color32(62,62,62,255), new Color32(63,63,63,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(64,64,64,255),
         new Color32(64,64,64,255), new Color32(63,63,63,255), new Color32(63,63,63,255), new Color32(61,61,61,250), new Color32(117,117,117,73), new Color32(150,150,150,0),
         new Color32(110,110,110,4), new Color32(78,78,77,195), new Color32(61,61,61,255), new Color32(65,65,65,254), new Color32(73,73,73,189), new Color32(65,65,65,245),
         new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(74,74,74,185), new Color32(67,67,67,251), new Color32(62,62,62,255),
         new Color32(72,72,72,227), new Color32(108,108,108,15), new Color32(101,101,101,65), new Color32(62,62,62,255), new Color32(63,63,63,255), new Color32(70,70,70,215),
         new Color32(82,82,81,0), new Color32(69,69,69,77), new Color32(64,64,64,251), new Color32(64,64,64,255), new Color32(68,68,68,111), new Color32(80,80,80,0),
         new Color32(74,74,74,185), new Color32(63,63,63,255), new Color32(61,61,61,255), new Color32(95,95,95,111), new Color32(83,83,83,155), new Color32(62,62,62,255),
         new Color32(64,64,64,255), new Color32(64,64,64,254), new Color32(67,67,67,150), new Color32(72,72,72,0), new Color32(70,70,70,90), new Color32(69,69,69,117),
         new Color32(73,73,72,0), new Color32(68,68,68,112), new Color32(64,64,64,249), new Color32(64,64,64,255), new Color32(63,63,63,255), new Color32(74,74,74,186),
         new Color32(73,73,73,214), new Color32(63,63,63,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(63,63,63,255), new Color32(70,70,70,158),
         new Color32(78,78,77,0), new Color32(78,78,77,0), new Color32(72,72,71,116), new Color32(63,63,63,255), new Color32(64,64,64,255), new Color32(64,64,64,255),
         new Color32(64,64,64,255), new Color32(68,68,68,211), new Color32(76,76,76,208), new Color32(62,62,62,255), new Color32(64,64,64,255), new Color32(64,64,64,255),
         new Color32(64,64,64,255), new Color32(71,71,71,122), new Color32(78,78,77,0), new Color32(78,78,77,0), new Color32(73,73,72,91), new Color32(64,64,64,252),
         new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(63,63,63,255), new Color32(70,70,70,208), new Color32(88,88,87,139), new Color32(61,61,62,255),
         new Color32(64,64,64,255), new Color32(64,64,64,246), new Color32(69,69,69,109), new Color32(73,73,73,0), new Color32(69,69,69,122), new Color32(68,68,68,157),
         new Color32(72,72,72,0), new Color32(69,69,69,79), new Color32(65,65,65,238), new Color32(64,64,64,255), new Color32(62,62,62,255), new Color32(78,78,78,178),
         new Color32(99,99,99,54), new Color32(62,62,63,255), new Color32(63,63,63,255), new Color32(70,70,70,216), new Color32(83,83,82,5), new Color32(69,69,69,108),
         new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(67,67,67,150), new Color32(82,82,81,3), new Color32(73,73,73,189), new Color32(63,63,63,255),
         new Color32(61,61,61,255), new Color32(94,94,93,97), new Color32(120,120,120,0), new Color32(87,87,87,175), new Color32(61,61,61,255), new Color32(64,64,64,255),
         new Color32(70,70,70,217), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(70,70,70,215),
         new Color32(65,65,65,255), new Color32(61,61,61,255), new Color32(80,80,80,215), new Color32(119,119,119,6), new Color32(151,151,151,0), new Color32(132,132,132,23),
         new Color32(68,68,67,210), new Color32(62,62,62,255), new Color32(63,63,63,255), new Color32(64,64,64,255), new Color32(64,64,64,255), new Color32(64,64,64,255),
         new Color32(64,64,64,255), new Color32(63,63,63,255), new Color32(62,62,62,255), new Color32(63,63,63,236), new Color32(124,124,124,50), new Color32(152,152,152,0),
         new Color32(148,148,148,0), new Color32(132,132,132,0), new Color32(90,90,89,23), new Color32(81,81,81,171), new Color32(63,63,63,255), new Color32(63,63,63,255),
         new Color32(63,63,63,255), new Color32(63,63,63,255), new Color32(62,62,62,255), new Color32(64,64,64,255), new Color32(71,71,71,190), new Color32(84,84,84,41),
         new Color32(125,125,125,0), new Color32(149,149,149,0), new Color32(148,148,148,0), new Color32(131,131,131,0), new Color32(94,94,93,0), new Color32(99,99,99,0),
         new Color32(85,85,85,57), new Color32(78,78,78,136), new Color32(73,73,73,205), new Color32(73,73,73,209), new Color32(77,77,77,152), new Color32(81,81,81,67),
         new Color32(84,84,84,0), new Color32(88,88,88,0), new Color32(124,124,124,0), new Color32(149,149,149,0),
        };
        #endregion

        #region Compressed Audio File
        readonly static Color32[] _compressedAudioFileData = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
 new Color32(130,153,172,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(181,210,235,255),
 new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
 new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255),
 new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(153,174,195,255), new Color32(153,174,195,255), new Color32(50,50,50,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255),
 new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(153,174,195,255),
 new Color32(153,174,195,255), new Color32(50,50,50,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(113,137,157,255), new Color32(153,174,195,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,228,196,255), new Color32(255,204,143,255), new Color32(255,184,100,255), new Color32(255,255,255,255),
 new Color32(255,167,63,255), new Color32(153,174,195,255), new Color32(153,174,195,255), new Color32(50,50,50,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(254,138,0,255),
 new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,184,100,255), new Color32(255,209,154,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(153,174,195,255), new Color32(153,174,195,255), new Color32(50,50,50,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(113,137,157,255), new Color32(153,174,195,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
 new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255), new Color32(130,153,172,255),
 new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(181,210,235,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Audio File
        readonly static Color32[] _audioFileData = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,255,255,255), new Color32(255,214,165,255), new Color32(255,198,130,255), new Color32(255,184,100,255), new Color32(255,255,255,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,255,255,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(255,167,63,255), new Color32(255,184,100,255), new Color32(255,204,143,255), new Color32(255,222,182,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(255,167,63,255),
 new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(255,167,63,255), new Color32(254,138,0,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255),
 new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(254,138,0,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Accept 16x16
        readonly static Color32[] _acceptIconData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(209,247,211,52), new Color32(142,234,146,128), new Color32(85,224,92,192), new Color32(45,217,53,237),
 new Color32(45,217,53,237), new Color32(85,224,92,192), new Color32(142,234,146,128), new Color32(209,247,211,52), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(164,238,167,103),
 new Color32(66,221,74,213), new Color32(72,222,79,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(66,221,74,213), new Color32(164,238,167,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(164,238,167,103), new Color32(41,216,50,241), new Color32(29,214,38,255), new Color32(209,247,211,255),
 new Color32(212,247,214,255), new Color32(43,217,52,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(41,216,50,241), new Color32(164,238,167,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(209,247,211,52),
 new Color32(66,221,74,213), new Color32(29,214,38,255), new Color32(57,219,65,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(149,236,153,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(66,221,74,213),
 new Color32(209,247,211,52), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(142,234,146,128), new Color32(29,214,38,255), new Color32(43,217,52,255),
 new Color32(218,248,219,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(57,219,65,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(142,234,146,128), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(85,224,92,192), new Color32(29,214,38,255), new Color32(70,221,77,255), new Color32(242,253,242,255), new Color32(245,253,246,255),
 new Color32(128,232,133,255), new Color32(255,255,255,255), new Color32(218,248,219,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(85,224,92,192), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(45,217,53,237),
 new Color32(29,214,38,255), new Color32(57,219,65,255), new Color32(184,242,187,255), new Color32(100,227,106,255), new Color32(29,214,38,255), new Color32(189,243,191,255),
 new Color32(247,254,247,255), new Color32(156,237,160,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(45,217,53,237), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(45,217,53,237), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(43,217,52,255), new Color32(215,248,217,255), new Color32(236,252,237,255),
 new Color32(114,229,120,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(45,217,53,237), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(85,224,92,192), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(43,217,52,255), new Color32(215,248,217,255), new Color32(220,249,221,255), new Color32(72,222,79,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(85,224,92,192), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(142,234,146,128),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(43,217,52,255), new Color32(202,245,204,255), new Color32(186,242,189,255), new Color32(86,224,92,255), new Color32(29,214,38,255),
 new Color32(142,234,146,128), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(209,247,211,52), new Color32(66,221,74,213), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(43,217,52,255), new Color32(170,240,173,255), new Color32(128,232,133,255), new Color32(66,221,74,213), new Color32(209,247,211,52), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(164,238,167,103), new Color32(41,216,50,241), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(95,226,101,245), new Color32(164,238,167,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(164,238,167,103), new Color32(66,221,74,213), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255),
 new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(29,214,38,255), new Color32(66,221,74,213), new Color32(164,238,167,103), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(209,247,211,52), new Color32(142,234,146,128), new Color32(85,224,92,192), new Color32(45,217,53,237), new Color32(45,217,53,237), new Color32(85,224,92,192),
 new Color32(142,234,146,128), new Color32(209,247,211,52), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Revert 16x16
        readonly static Color32[] _revertIconData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,52), new Color32(36,165,255,128), new Color32(36,165,255,192), new Color32(36,165,255,237),
 new Color32(36,165,255,237), new Color32(36,165,255,192), new Color32(36,165,255,128), new Color32(36,165,255,52), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,103),
 new Color32(36,165,255,213), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,213), new Color32(36,165,255,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,103), new Color32(36,165,255,241), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(255,255,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,241), new Color32(36,165,255,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,52),
 new Color32(36,165,255,213), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,213),
 new Color32(36,165,255,52), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,128), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(255,255,255,255), new Color32(252,254,255,255), new Color32(252,254,255,255), new Color32(220,241,255,255),
 new Color32(132,205,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,128), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(36,165,255,192), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(255,255,255,255),
 new Color32(255,255,255,255), new Color32(86,185,255,255), new Color32(86,185,255,255), new Color32(176,223,255,255), new Color32(241,249,255,255), new Color32(132,205,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,192), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,237),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(255,255,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(176,223,255,255), new Color32(220,241,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,237), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,237), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(86,185,255,255), new Color32(252,254,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,237), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(36,165,255,192), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(195,230,255,255), new Color32(254,255,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,192), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,128),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(132,205,255,255), new Color32(241,249,255,255), new Color32(176,223,255,255), new Color32(86,185,255,255),
 new Color32(86,185,255,255), new Color32(176,223,255,255), new Color32(241,249,255,255), new Color32(132,205,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,128), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,52), new Color32(36,165,255,213), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(132,205,255,255), new Color32(220,241,255,255), new Color32(252,254,255,255), new Color32(252,254,255,255), new Color32(220,241,255,255),
 new Color32(132,205,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,213), new Color32(36,165,255,52), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(36,165,255,103), new Color32(36,165,255,241), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,241), new Color32(36,165,255,103), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(36,165,255,103), new Color32(36,165,255,213), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255),
 new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,255), new Color32(36,165,255,213), new Color32(36,165,255,103), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(36,165,255,52), new Color32(36,165,255,128), new Color32(36,165,255,192), new Color32(36,165,255,237), new Color32(36,165,255,237), new Color32(36,165,255,192),
 new Color32(36,165,255,128), new Color32(36,165,255,52), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};

        #endregion

        #region Lock 16x16
        readonly static Color32[] _lockIconData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(176,123,38,255), new Color32(168,118,36,255), new Color32(162,113,36,255), new Color32(157,110,34,255), new Color32(154,108,33,255),
 new Color32(153,107,33,255), new Color32(154,108,34,255), new Color32(157,110,34,255), new Color32(162,114,35,255), new Color32(168,118,37,255), new Color32(176,123,38,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(186,131,39,255),
 new Color32(180,127,38,255), new Color32(176,124,37,255), new Color32(171,121,36,255), new Color32(168,119,36,255), new Color32(167,119,35,255), new Color32(168,119,36,255),
 new Color32(172,121,36,255), new Color32(175,124,37,255), new Color32(179,127,38,255), new Color32(185,131,39,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(199,141,39,255), new Color32(196,139,39,255), new Color32(193,137,39,255),
 new Color32(191,136,38,255), new Color32(189,135,37,255), new Color32(189,134,38,255), new Color32(189,135,37,255), new Color32(191,135,38,255), new Color32(193,137,39,255),
 new Color32(196,139,39,255), new Color32(199,141,39,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(212,152,40,255), new Color32(212,152,40,255), new Color32(210,151,40,255), new Color32(211,151,40,255), new Color32(210,151,40,255),
 new Color32(211,151,40,255), new Color32(210,151,40,255), new Color32(210,151,40,255), new Color32(210,151,40,255), new Color32(211,152,40,255), new Color32(211,152,40,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(223,162,43,255),
 new Color32(225,164,44,255), new Color32(224,164,48,255), new Color32(224,164,48,255), new Color32(225,165,50,255), new Color32(224,165,49,255), new Color32(224,165,49,255),
 new Color32(224,164,49,255), new Color32(224,164,47,255), new Color32(224,163,45,255), new Color32(223,162,42,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(227,170,52,255), new Color32(227,171,57,255), new Color32(228,173,60,255),
 new Color32(229,174,63,255), new Color32(230,175,65,255), new Color32(229,175,66,255), new Color32(229,175,65,255), new Color32(229,174,63,255), new Color32(229,173,60,255),
 new Color32(227,171,57,255), new Color32(227,170,52,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(230,176,62,255), new Color32(231,180,69,255), new Color32(232,180,73,255), new Color32(232,182,78,255), new Color32(233,184,80,255),
 new Color32(233,184,81,255), new Color32(233,184,81,255), new Color32(232,182,78,255), new Color32(232,181,73,255), new Color32(231,179,69,255), new Color32(231,176,62,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(233,181,70,255),
 new Color32(234,184,78,255), new Color32(234,186,83,255), new Color32(235,188,87,255), new Color32(235,189,90,255), new Color32(235,190,92,255), new Color32(235,189,90,255),
 new Color32(235,188,87,255), new Color32(234,186,83,255), new Color32(234,184,78,255), new Color32(233,181,70,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255),
 new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Unlock 16x16
        readonly static Color32[] _unlockIconData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(213,149,46,255), new Color32(213,149,46,255), new Color32(213,149,47,255), new Color32(214,150,46,255), new Color32(213,150,46,255),
 new Color32(214,150,46,255), new Color32(213,149,47,255), new Color32(213,150,46,255), new Color32(214,150,46,255), new Color32(213,150,47,255), new Color32(213,150,46,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(216,152,45,255),
 new Color32(216,152,45,255), new Color32(216,152,45,255), new Color32(215,152,45,255), new Color32(215,152,45,255), new Color32(215,153,45,255), new Color32(215,152,45,255),
 new Color32(216,152,45,255), new Color32(215,152,45,255), new Color32(215,152,45,255), new Color32(215,152,45,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(218,155,43,255), new Color32(218,155,43,255), new Color32(218,155,44,255),
 new Color32(218,155,43,255), new Color32(218,155,43,255), new Color32(218,155,44,255), new Color32(218,155,43,255), new Color32(218,154,43,255), new Color32(218,155,44,255),
 new Color32(218,155,43,255), new Color32(218,155,43,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(221,158,42,255), new Color32(221,158,42,255), new Color32(220,158,42,255), new Color32(221,158,42,255), new Color32(220,158,42,255),
 new Color32(221,158,42,255), new Color32(220,158,42,255), new Color32(220,158,42,255), new Color32(220,158,42,255), new Color32(220,158,42,255), new Color32(220,158,42,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(223,161,41,255),
 new Color32(224,162,40,255), new Color32(223,161,41,255), new Color32(223,161,40,255), new Color32(224,161,41,255), new Color32(223,161,40,255), new Color32(223,161,40,255),
 new Color32(223,161,41,255), new Color32(223,161,40,255), new Color32(223,161,41,255), new Color32(223,161,40,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(225,164,39,255), new Color32(225,164,39,255), new Color32(225,164,39,255),
 new Color32(226,164,39,255), new Color32(226,164,39,255), new Color32(225,164,39,255), new Color32(225,164,39,255), new Color32(226,164,39,255), new Color32(226,164,39,255),
 new Color32(225,164,39,255), new Color32(225,164,39,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(227,166,38,255), new Color32(227,167,38,255), new Color32(227,166,38,255), new Color32(227,166,38,255), new Color32(228,166,37,255),
 new Color32(227,166,38,255), new Color32(228,166,38,255), new Color32(227,166,38,255), new Color32(227,167,38,255), new Color32(227,166,38,255), new Color32(228,166,38,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(229,168,37,255),
 new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255),
 new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(229,168,37,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(171,171,171,255), new Color32(171,171,171,255),
 new Color32(171,171,171,255), new Color32(171,171,171,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Next
        readonly static Color32[] _nextClosedData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(29,142,214,255),
 new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255),
 new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(0,52,104,255),
 new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255),
 new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(0,52,104,255), new Color32(0,52,104,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255),
 new Color32(36,146,215,255), new Color32(32,143,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255),
 new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(29,142,214,255), new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(69,162,221,255), new Color32(66,161,221,255),
 new Color32(63,159,220,255), new Color32(59,157,219,255), new Color32(54,154,219,255), new Color32(44,150,217,255), new Color32(33,144,215,255), new Color32(29,142,214,255),
 new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255),
 new Color32(0,52,104,255), new Color32(69,162,221,255), new Color32(57,156,219,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(80,167,223,255),
 new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(0,52,104,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Refresh
        readonly static Color32[] _refreshData16x16 = new Color32[] {
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255),
 new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255),
 new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(7,72,113,255),
 new Color32(25,106,157,255), new Color32(40,134,194,255), new Color32(51,152,218,255), new Color32(0,60,98,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(52,155,221,255), new Color32(42,136,196,255), new Color32(33,121,177,255), new Color32(27,108,161,255), new Color32(0,60,98,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(7,72,113,255), new Color32(34,121,178,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(52,155,221,255), new Color32(0,60,98,255), new Color32(52,155,221,255), new Color32(51,152,218,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(27,108,161,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255),
 new Color32(25,106,157,255), new Color32(52,155,221,255), new Color32(45,143,206,255), new Color32(27,109,162,255), new Color32(12,81,125,255), new Color32(0,60,98,255),
 new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(7,72,113,255),
 new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(40,134,194,255), new Color32(52,155,221,255),
 new Color32(27,109,162,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(42,136,196,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(25,106,157,255), new Color32(0,60,98,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(51,152,218,255), new Color32(52,155,221,255), new Color32(12,81,125,255), new Color32(0,60,98,255),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(33,121,177,255), new Color32(4,68,109,255), new Color32(0,60,98,255), new Color32(27,109,162,255),
 new Color32(52,155,221,255), new Color32(40,134,194,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255),
 new Color32(51,152,218,255), new Color32(52,155,221,255), new Color32(1,63,101,255), new Color32(106,141,163,149), new Color32(255,255,255,0), new Color32(0,60,98,255),
 new Color32(0,61,99,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(12,81,125,255), new Color32(52,155,221,255), new Color32(51,152,218,255),
 new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(51,152,218,255), new Color32(52,155,221,255),
 new Color32(12,81,125,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,61,99,255), new Color32(0,60,98,255), new Color32(255,255,255,0),
 new Color32(106,141,163,149), new Color32(1,63,101,255), new Color32(52,155,221,255), new Color32(51,152,218,255), new Color32(0,60,98,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(40,134,194,255), new Color32(52,155,221,255), new Color32(27,109,162,255), new Color32(0,60,98,255),
 new Color32(4,68,109,255), new Color32(33,121,177,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(12,81,125,255),
 new Color32(52,155,221,255), new Color32(51,152,218,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255),
 new Color32(25,106,157,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(42,136,196,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(27,109,162,255), new Color32(52,155,221,255), new Color32(40,134,194,255),
 new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(7,72,113,255), new Color32(52,155,221,255),
 new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(0,60,98,255), new Color32(12,81,125,255),
 new Color32(27,109,162,255), new Color32(45,143,206,255), new Color32(52,155,221,255), new Color32(25,106,157,255), new Color32(0,60,98,255), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(27,108,161,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(51,152,218,255), new Color32(52,155,221,255), new Color32(0,60,98,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(34,121,178,255), new Color32(7,72,113,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255),
 new Color32(27,108,161,255), new Color32(33,121,177,255), new Color32(42,136,196,255), new Color32(52,155,221,255), new Color32(52,155,221,255), new Color32(52,155,221,255),
 new Color32(0,60,98,255), new Color32(51,152,218,255), new Color32(40,134,194,255), new Color32(25,106,157,255), new Color32(7,72,113,255), new Color32(0,60,98,255),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255),
 new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255),
 new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(0,60,98,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
 new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
};
        #endregion

        #region Builtin Shader
        readonly static Color32[] _builtinShaderData16x16 = new Color32[] {
          new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,158),
         new Color32(35,34,36,186), new Color32(35,34,36,196), new Color32(35,34,36,207), new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,218),
         new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,207), new Color32(35,34,36,196), new Color32(35,34,36,186), new Color32(35,34,36,158),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,186), new Color32(163,102,136,255), new Color32(165,104,137,255),
         new Color32(168,105,139,255), new Color32(170,106,140,255), new Color32(173,107,141,255), new Color32(175,108,142,255), new Color32(177,109,144,255), new Color32(180,111,145,255),
         new Color32(182,112,146,255), new Color32(184,113,148,255), new Color32(186,113,147,255), new Color32(35,34,36,186), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,196), new Color32(144,104,137,255), new Color32(146,105,139,255), new Color32(138,98,130,255), new Color32(70,49,66,255),
         new Color32(36,26,35,255), new Color32(32,22,30,255), new Color32(59,42,55,255), new Color32(140,98,129,255), new Color32(158,113,148,255), new Color32(161,114,148,255),
         new Color32(161,114,148,255), new Color32(35,34,36,196), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207),
         new Color32(121,105,139,255), new Color32(123,106,140,255), new Color32(118,102,134,255), new Color32(70,60,80,255), new Color32(98,85,111,255), new Color32(87,75,98,255),
         new Color32(36,29,40,255), new Color32(26,21,30,255), new Color32(132,112,146,255), new Color32(135,115,149,255), new Color32(135,115,149,255), new Color32(35,34,36,207),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207), new Color32(112,106,147,255), new Color32(114,107,148,255),
         new Color32(115,108,149,255), new Color32(117,109,151,255), new Color32(118,111,152,255), new Color32(120,112,154,255), new Color32(96,90,124,255), new Color32(1,1,2,255),
         new Color32(111,104,142,255), new Color32(124,116,158,255), new Color32(125,116,157,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,218), new Color32(115,107,176,255), new Color32(116,108,178,255), new Color32(117,109,179,255), new Color32(119,111,181,255),
         new Color32(121,112,182,255), new Color32(116,107,175,255), new Color32(55,48,80,255), new Color32(14,12,20,255), new Color32(123,113,182,255), new Color32(127,116,187,255),
         new Color32(126,116,188,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,218),
         new Color32(125,110,206,255), new Color32(127,111,208,255), new Color32(129,112,210,255), new Color32(130,113,212,255), new Color32(82,70,131,255), new Color32(11,9,18,255),
         new Color32(30,25,48,255), new Color32(114,98,183,255), new Color32(135,117,218,255), new Color32(135,118,219,255), new Color32(135,117,218,255), new Color32(35,34,36,218),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,218), new Color32(133,111,221,255), new Color32(134,112,223,255),
         new Color32(135,112,223,255), new Color32(77,60,120,255), new Color32(9,7,15,255), new Color32(91,72,143,255), new Color32(135,113,224,255), new Color32(139,116,229,255),
         new Color32(139,116,231,255), new Color32(140,117,231,255), new Color32(139,117,230,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,214), new Color32(152,114,235,255), new Color32(152,115,236,255), new Color32(152,115,236,255), new Color32(10,7,18,255),
         new Color32(123,90,186,255), new Color32(155,116,240,255), new Color32(155,117,240,255), new Color32(155,117,242,255), new Color32(156,117,241,255), new Color32(156,118,242,255),
         new Color32(155,117,241,255), new Color32(35,34,36,210), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207),
         new Color32(159,103,239,255), new Color32(159,103,240,255), new Color32(160,103,241,255), new Color32(33,20,56,255), new Color32(88,56,138,255), new Color32(157,107,234,255),
         new Color32(129,86,193,255), new Color32(88,56,138,255), new Color32(162,103,244,255), new Color32(160,103,240,255), new Color32(158,102,236,255), new Color32(35,34,36,196),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207), new Color32(160,90,238,255), new Color32(161,91,239,255),
         new Color32(162,91,240,255), new Color32(146,92,214,255), new Color32(47,27,75,255), new Color32(18,10,29,255), new Color32(32,18,51,255), new Color32(123,79,185,255),
         new Color32(159,91,238,255), new Color32(155,90,230,255), new Color32(153,88,227,249), new Color32(35,34,36,196), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,196), new Color32(181,84,237,255), new Color32(181,85,238,255), new Color32(183,84,238,255), new Color32(184,84,240,255),
         new Color32(184,85,240,255), new Color32(186,85,241,255), new Color32(186,85,241,255), new Color32(173,84,231,255), new Color32(169,83,228,255), new Color32(164,81,226,249),
         new Color32(72,29,93,237), new Color32(35,34,36,150), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,186),
         new Color32(193,84,230,255), new Color32(197,84,232,255), new Color32(197,84,233,255), new Color32(197,84,233,255), new Color32(198,85,233,255), new Color32(198,85,233,255),
         new Color32(188,83,226,255), new Color32(188,83,226,255), new Color32(188,81,227,249), new Color32(82,31,102,231), new Color32(35,34,36,150), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,158), new Color32(35,34,36,186), new Color32(35,34,36,196),
         new Color32(35,34,36,207), new Color32(35,34,36,207), new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,207), new Color32(35,34,36,196),
         new Color32(35,34,36,196), new Color32(35,34,36,158), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
        };
        #endregion

        #region Shader
        readonly static Color32[] _shaderData16x16 = new Color32[] {
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,158),
         new Color32(35,34,36,186), new Color32(35,34,36,196), new Color32(35,34,36,207), new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,218),
         new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,207), new Color32(35,34,36,196), new Color32(35,34,36,186), new Color32(35,34,36,158),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,186), new Color32(191,205,136,255), new Color32(194,208,137,255),
         new Color32(197,210,139,255), new Color32(200,212,140,255), new Color32(203,215,141,255), new Color32(205,217,142,255), new Color32(208,219,144,255), new Color32(211,222,145,255),
         new Color32(214,224,146,255), new Color32(216,226,148,255), new Color32(218,227,147,255), new Color32(35,34,36,186), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,196), new Color32(169,208,137,255), new Color32(172,210,139,255), new Color32(162,197,130,255), new Color32(82,98,66,255),
         new Color32(43,52,35,255), new Color32(38,45,30,255), new Color32(70,85,55,255), new Color32(164,197,129,255), new Color32(186,226,148,255), new Color32(189,228,148,255),
         new Color32(189,229,148,255), new Color32(35,34,36,196), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207),
         new Color32(142,210,139,255), new Color32(144,212,140,255), new Color32(139,205,134,255), new Color32(82,120,80,255), new Color32(115,171,111,255), new Color32(102,151,98,255),
         new Color32(42,59,40,255), new Color32(31,42,30,255), new Color32(155,225,146,255), new Color32(158,230,149,255), new Color32(159,231,149,255), new Color32(35,34,36,207),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207), new Color32(132,212,147,255), new Color32(134,215,148,255),
         new Color32(135,217,149,255), new Color32(137,219,151,255), new Color32(139,222,152,255), new Color32(141,224,154,255), new Color32(113,181,124,255), new Color32(2,3,2,255),
         new Color32(131,208,142,255), new Color32(146,232,158,255), new Color32(147,232,157,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,218), new Color32(135,215,176,255), new Color32(136,217,178,255), new Color32(138,219,179,255), new Color32(140,222,181,255),
         new Color32(142,224,182,255), new Color32(136,214,175,255), new Color32(65,97,80,255), new Color32(17,24,20,255), new Color32(144,226,182,255), new Color32(149,233,187,255),
         new Color32(148,233,188,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,218),
         new Color32(147,221,206,255), new Color32(149,223,208,255), new Color32(151,225,210,255), new Color32(153,227,212,255), new Color32(96,140,131,255), new Color32(13,18,18,255),
         new Color32(36,50,48,255), new Color32(134,197,183,255), new Color32(158,235,218,255), new Color32(158,236,219,255), new Color32(158,235,218,255), new Color32(35,34,36,218),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,218), new Color32(156,222,221,255), new Color32(157,224,223,255),
         new Color32(159,225,223,255), new Color32(91,120,120,255), new Color32(11,14,15,255), new Color32(107,144,143,255), new Color32(159,227,224,255), new Color32(163,232,229,255),
         new Color32(163,233,231,255), new Color32(164,234,231,255), new Color32(163,234,230,255), new Color32(35,34,36,218), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,214), new Color32(178,228,235,255), new Color32(179,230,236,255), new Color32(178,230,236,255), new Color32(12,14,18,255),
         new Color32(145,180,186,255), new Color32(182,233,240,255), new Color32(182,234,240,255), new Color32(182,234,242,255), new Color32(183,235,241,255), new Color32(183,236,242,255),
         new Color32(182,235,241,255), new Color32(35,34,36,210), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207),
         new Color32(187,206,239,255), new Color32(187,206,240,255), new Color32(188,207,241,255), new Color32(39,41,56,255), new Color32(104,113,138,255), new Color32(184,214,234,255),
         new Color32(151,172,193,255), new Color32(104,113,138,255), new Color32(190,207,244,255), new Color32(188,206,240,255), new Color32(185,204,236,255), new Color32(35,34,36,196),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,207), new Color32(188,181,238,255), new Color32(189,183,239,255),
         new Color32(190,182,240,255), new Color32(172,185,214,255), new Color32(55,54,75,255), new Color32(21,21,29,255), new Color32(38,36,51,255), new Color32(145,158,185,255),
         new Color32(187,182,238,255), new Color32(182,180,230,255), new Color32(179,180,226,242), new Color32(35,34,36,196), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(35,34,36,196), new Color32(212,169,237,255), new Color32(213,170,238,255), new Color32(215,168,238,255), new Color32(216,169,240,255),
         new Color32(216,171,240,255), new Color32(218,170,241,255), new Color32(218,170,241,255), new Color32(203,168,231,255), new Color32(198,167,228,255), new Color32(192,166,225,242),
         new Color32(74,63,79,218), new Color32(35,34,36,150), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,186),
         new Color32(227,169,230,255), new Color32(231,169,232,255), new Color32(231,169,233,255), new Color32(231,169,233,255), new Color32(233,170,233,255), new Color32(233,170,233,255),
         new Color32(221,166,226,255), new Color32(221,166,226,255), new Color32(221,166,226,242), new Color32(84,68,85,207), new Color32(35,34,36,150), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(35,34,36,158), new Color32(35,34,36,186), new Color32(35,34,36,196),
         new Color32(35,34,36,207), new Color32(35,34,36,207), new Color32(35,34,36,218), new Color32(35,34,36,218), new Color32(35,34,36,207), new Color32(35,34,36,196),
         new Color32(35,34,36,196), new Color32(35,34,36,158), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
        };
        #endregion

        #region Hidden
        readonly static Color32[] _hiddenData16x16 = new Color32[] {
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(46,46,46,209),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(200,136,42,255), new Color32(200,136,42,255),
         new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(255,255,255,0), new Color32(46,46,46,209), new Color32(46,46,46,209),
         new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255),
         new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255),
         new Color32(242,242,242,255), new Color32(242,242,242,255), new Color32(48,154,228,255), new Color32(6,125,209,255), new Color32(6,125,209,255), new Color32(48,154,228,255),
         new Color32(242,242,242,255), new Color32(242,242,242,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(200,136,42,255), new Color32(46,46,46,209),
         new Color32(46,46,46,209), new Color32(200,136,42,255), new Color32(206,207,255,255), new Color32(206,207,255,255), new Color32(242,242,242,255), new Color32(6,125,209,255),
         new Color32(6,125,209,255), new Color32(72,170,239,255), new Color32(72,170,239,255), new Color32(6,125,209,255), new Color32(6,125,209,255), new Color32(206,207,255,255),
         new Color32(242,242,242,255), new Color32(242,242,242,255), new Color32(155,103,27,255), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(200,136,42,255),
         new Color32(206,207,255,255), new Color32(206,207,255,255), new Color32(242,242,242,255), new Color32(6,125,209,255), new Color32(72,170,239,255), new Color32(44,44,44,255),
         new Color32(74,74,74,255), new Color32(72,170,239,255), new Color32(6,125,209,255), new Color32(206,207,255,255), new Color32(242,242,242,255), new Color32(242,242,242,255),
         new Color32(155,103,27,255), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(200,136,42,255), new Color32(206,207,255,255), new Color32(206,207,255,255),
         new Color32(242,242,242,255), new Color32(6,125,209,255), new Color32(72,170,239,255), new Color32(44,44,44,255), new Color32(74,74,74,255), new Color32(72,170,239,255),
         new Color32(6,125,209,255), new Color32(206,207,255,255), new Color32(242,242,242,255), new Color32(242,242,242,255), new Color32(155,103,27,255), new Color32(46,46,46,209),
         new Color32(46,46,46,209), new Color32(200,136,42,255), new Color32(206,207,255,255), new Color32(206,207,255,255), new Color32(242,242,242,255), new Color32(6,125,209,255),
         new Color32(6,125,209,255), new Color32(72,170,239,255), new Color32(72,170,239,255), new Color32(6,125,209,255), new Color32(6,125,209,255), new Color32(206,207,255,255),
         new Color32(242,242,242,255), new Color32(242,242,242,255), new Color32(155,103,27,255), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(200,136,42,255),
         new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(206,207,255,255), new Color32(64,158,225,255), new Color32(48,154,228,255), new Color32(6,125,209,255),
         new Color32(6,125,209,255), new Color32(48,154,228,255), new Color32(64,158,225,255), new Color32(242,242,242,255), new Color32(155,103,27,255), new Color32(155,103,27,255),
         new Color32(155,103,27,255), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(155,103,27,255), new Color32(155,103,27,255),
         new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255),
         new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(46,46,46,209), new Color32(46,46,46,209),
         new Color32(255,255,255,0), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(155,103,27,255), new Color32(155,103,27,255),
         new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255), new Color32(155,103,27,255),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209),
         new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(46,46,46,209), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
         new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
        };
        #endregion

        #endregion
    }
}
